<?php
/**
 * Activator class - handles plugin activation
 *
 * @package Marveo_Connector
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marveo_Activator class
 */
class Marveo_Activator {
	/**
	 * Activate the plugin
	 *
	 * @return void
	 */
	public static function activate() {
		// Check if already activated
		$already_activated = get_option( 'marveo_activated_at' );

		// Generate activation data
		$token          = marveo_generate_token();
		$site_id        = marveo_generate_site_id();
		$expiry_time    = marveo_get_token_expiry();
		$activation_key = current_time( 'timestamp' );

		// Store activation token and metadata
		update_option( 'marveo_activation_token', $token );
		update_option( 'marveo_activation_token_expires', current_time( 'timestamp' ) + $expiry_time );
		update_option( 'marveo_activated_at', $activation_key );
		update_option( 'marveo_version', MARVEO_CONNECTOR_VERSION );
		update_option( 'marveo_site_id', $site_id );
		update_option( 'marveo_connector_status', 'pending_setup' );
		update_option( 'marveo_first_admin_created', false );
		update_option( 'marveo_deployment_profile', marveo_get_default_deployment_profile() );
		update_option( 'marveo_deployment_status', marveo_get_deployment_status() );
		update_option( 'marveo_deployment_setup_completed', false );
		update_option( 'marveo_deployment_validation_passed', false );
		update_option( 'marveo_deployment_last_validated_at', '' );

		// Log activation
		marveo_log( 'Plugin activated. Token: ' . $token . ' Site ID: ' . $site_id );

		// Fire activation hook
		do_action( 'marveo_activated' );

		// Set transient to show activation notice
		set_transient( 'marveo_activation_notice', true, 5 * MINUTE_IN_SECONDS );
	}
}
