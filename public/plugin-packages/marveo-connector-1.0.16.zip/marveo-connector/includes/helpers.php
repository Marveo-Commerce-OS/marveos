<?php
/**
 * Helper functions for Marvéo Connector
 *
 * @package Marveo_Connector
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generate a secure random token
 *
 * @param int $length Length of the token (default: 32)
 * @return string Random token
 */
function marveo_generate_token( $length = 32 ) {
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$token      = '';

	if ( function_exists( 'wp_rand' ) ) {
		for ( $i = 0; $i < $length; $i++ ) {
			$token .= $characters[ wp_rand( 0, strlen( $characters ) - 1 ) ];
		}
	} else {
		$token = bin2hex( random_bytes( $length / 2 ) );
		$token = substr( $token, 0, $length );
	}

	return $token;
}

/**
 * Generate a unique site ID
 *
 * @return string Unique site ID
 */
function marveo_generate_site_id() {
	$site_url = get_option( 'siteurl' );
	$timestamp = time();
	$unique_id = substr( md5( $site_url . $timestamp ), 0, 10 );
	return 'marveo_' . $unique_id;
}

/**
 * Check if activation token is valid and not expired
 *
 * @param string $token Token to validate
 * @return bool True if valid, false otherwise
 */
function marveo_is_token_valid( $token ) {
	$stored_token = get_option( 'marveo_activation_token' );
	$expiry       = get_option( 'marveo_activation_token_expires' );

	if ( ! $stored_token || ! $expiry ) {
		return false;
	}

	if ( $token !== $stored_token ) {
		return false;
	}

	if ( time() > $expiry ) {
		return false;
	}

	return true;
}

/**
 * Get activation token expiry time in seconds
 *
 * @return int Expiry time in seconds (default: 24 hours)
 */
function marveo_get_token_expiry() {
	return apply_filters( 'marveo_activation_token_expiry', 60 * 60 * 24 );
}

/**
 * Get connector status
 *
 * @return string Status: 'pending_setup', 'active', or 'disconnected'
 */
function marveo_get_connector_status() {
	return get_option( 'marveo_connector_status', 'pending_setup' );
}

/**
 * Set connector status
 *
 * @param string $status New status
 * @return bool Success or failure
 */
function marveo_set_connector_status( $status ) {
	return update_option( 'marveo_connector_status', $status );
}

/**
 * Get site ID
 *
 * @return string Site ID
 */
function marveo_get_site_id() {
	return get_option( 'marveo_site_id' );
}

/**
 * Get WooCommerce version
 *
 * @return string|false WooCommerce version or false if not installed
 */
function marveo_get_woocommerce_version() {
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	if ( ! is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
		return false;
	}

	if ( defined( 'WC_VERSION' ) ) {
		return WC_VERSION;
	}

	return false;
}

/**
 * Check if JWT Auth is enabled
 *
 * @return bool True if JWT Auth is enabled
 */
function marveo_is_jwt_enabled() {
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	return is_plugin_active( 'jwt-authentication-for-wp-rest-api/jwt-auth.php' );
}

/**
 * Get list of active plugins
 *
 * @return array Active plugin slugs
 */
function marveo_get_active_plugins() {
	$active_plugins = get_option( 'active_plugins', array() );
	$plugins        = array();

	foreach ( $active_plugins as $plugin ) {
		$parts     = explode( '/', $plugin );
		$plugins[] = $parts[0];
	}

	return $plugins;
}

/**
 * Sanitize and validate email
 *
 * @param string $email Email to validate
 * @return string|bool Sanitized email or false
 */
function marveo_validate_email( $email ) {
	$email = sanitize_email( $email );
	if ( is_email( $email ) ) {
		return $email;
	}
	return false;
}

/**
 * Sanitize username
 *
 * @param string $username Username to sanitize
 * @return string Sanitized username
 */
function marveo_sanitize_username( $username ) {
	return sanitize_user( $username );
}

/**
 * Check if user has required capability for Marvéo access
 *
 * @param int $user_id User ID
 * @return bool True if user can access Marvéo API
 */
function marveo_user_has_capability( $user_id ) {
	$user = get_userdata( $user_id );

	if ( ! $user ) {
		return false;
	}

	// Check if user has administrator or shop_manager role
	return $user->has_cap( 'manage_options' ) || $user->has_cap( 'manage_woocommerce' );
}

/**
 * Log Marvéo events for debugging
 *
 * @param string $message Log message
 * @param string $level Log level: 'info', 'warning', 'error'
 * @return void
 */
function marveo_log( $message, $level = 'info' ) {
	$timestamped = '[' . current_time( 'mysql' ) . '] [' . strtoupper( $level ) . '] ' . $message;

	$existing_logs = get_option( 'marveo_runtime_logs', array() );
	if ( ! is_array( $existing_logs ) ) {
		$existing_logs = array();
	}
	$existing_logs[] = $timestamped;
	if ( count( $existing_logs ) > 200 ) {
		$existing_logs = array_slice( $existing_logs, -200 );
	}
	update_option( 'marveo_runtime_logs', $existing_logs );

	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		error_log( '[Marveo Connector] ' . $timestamped );
	}
}

/**
 * Get Marvéo deployment URL
 *
 * @return string|empty Deployment URL or empty string
 */
function marveo_get_deployment_url() {
	$profile = marveo_get_deployment_profile();
	if ( ! empty( $profile['frontend_url'] ) ) {
		return $profile['frontend_url'];
	}

	return get_option( 'marveo_deployment_url', '' );
}

/**
 * Get Marvéo plugin update API URL.
 *
 * @return string Update API URL or empty string.
 */
function marveo_get_update_api_url() {
	return get_option( 'marveo_update_api_url', '' );
}

/**
 * Get an environment variable without exposing it in the UI.
 *
 * @param string $key Environment key.
 * @return string
 */
function marveo_get_env_value( $key ) {
	$env = getenv( $key );
	if ( false !== $env && '' !== $env ) {
		return trim( (string) $env );
	}

	return '';
}

/**
 * Default deployment profile structure.
 *
 * @return array<string,mixed>
 */
function marveo_get_default_deployment_profile() {
	return array(
		'mode'           => 'wordpress',
		'business_name'   => get_option( 'blogname', 'Marvéo' ),
		'industry'       => '',
		'business_model' => 'Hybrid',
		'country_currency' => 'USD',
		'contact_email'  => get_option( 'admin_email', '' ),
		'whatsapp_phone' => '',
		'logo'           => '',
		'favicon'        => '',
		'primary_color'  => '#14B8A6',
		'secondary_color'=> '#A3E635',
		'typography'     => 'Inter',
		'header_footer_style' => 'Standard',
		'woocommerce_enabled' => marveo_get_woocommerce_version() ? true : false,
		'checkout_mode'  => marveo_get_woocommerce_version() ? 'Native WooCommerce' : 'Enquiry only',
		'product_source' => 'WooCommerce',
		'tax_shipping_payment_status' => 'unchecked',
		'pages'          => array(),
		'products'       => array(),
		'blog_posts'     => array(),
		'banners'        => array(),
		'testimonials'   => array(),
		'contact_details'=> array(),
		'social_links'   => array(),
		'active_modules' => array(),
		'frontend_url'   => '',
		'wordpress_site_url' => get_option( 'siteurl', '' ),
		'wordpress_api_url'   => get_option( 'siteurl', '' ) . '/wp-json',
		'woocommerce_api_url' => '',
		'revalidation_secret' => '',
		'license_key'    => get_option( 'license_key', '' ),
		'google_analytics' => '',
		'meta_pixel'     => '',
		'search_console' => '',
		'crm_webhook'    => '',
		'email_provider' => '',
		'payment_gateway_status' => '',
		'api_credentials_status' => '',
	);
}

/**
 * Get the saved deployment profile.
 *
 * @return array<string,mixed>
 */
function marveo_get_deployment_profile() {
	$profile = get_option( 'marveo_deployment_profile', array() );
	if ( ! is_array( $profile ) ) {
		$profile = array();
	}

	$profile = array_merge( marveo_get_default_deployment_profile(), $profile );
	if ( empty( $profile['frontend_url'] ) ) {
		$profile['frontend_url'] = get_option( 'marveo_deployment_url', '' );
	}

	if ( empty( $profile['active_modules'] ) || ! is_array( $profile['active_modules'] ) ) {
		$profile['active_modules'] = array();
	}

	return $profile;
}

/**
 * Sanitize a deployment profile payload.
 *
 * @param array<string,mixed> $profile Raw profile.
 * @return array<string,mixed>
 */
function marveo_sanitize_deployment_profile( $profile ) {
	$defaults = marveo_get_default_deployment_profile();
	$profile  = is_array( $profile ) ? $profile : array();

	$sanitized = $defaults;
	$sanitized['mode'] = 'headless' === ( $profile['mode'] ?? '' ) ? 'headless' : 'wordpress';
	$sanitized['business_name'] = sanitize_text_field( $profile['business_name'] ?? $defaults['business_name'] );
	$sanitized['industry'] = sanitize_text_field( $profile['industry'] ?? '' );
	$sanitized['business_model'] = sanitize_text_field( $profile['business_model'] ?? $defaults['business_model'] );
	$sanitized['country_currency'] = sanitize_text_field( $profile['country_currency'] ?? $defaults['country_currency'] );
	$sanitized['contact_email'] = sanitize_email( $profile['contact_email'] ?? $defaults['contact_email'] );
	$sanitized['whatsapp_phone'] = sanitize_text_field( $profile['whatsapp_phone'] ?? '' );
	$sanitized['logo'] = esc_url_raw( $profile['logo'] ?? '' );
	$sanitized['favicon'] = esc_url_raw( $profile['favicon'] ?? '' );
	$sanitized['primary_color'] = sanitize_hex_color( $profile['primary_color'] ?? $defaults['primary_color'] ) ?: $defaults['primary_color'];
	$sanitized['secondary_color'] = sanitize_hex_color( $profile['secondary_color'] ?? $defaults['secondary_color'] ) ?: $defaults['secondary_color'];
	$sanitized['typography'] = sanitize_text_field( $profile['typography'] ?? $defaults['typography'] );
	$sanitized['header_footer_style'] = sanitize_text_field( $profile['header_footer_style'] ?? $defaults['header_footer_style'] );
	$sanitized['woocommerce_enabled'] = ! empty( $profile['woocommerce_enabled'] );
	$sanitized['checkout_mode'] = sanitize_text_field( $profile['checkout_mode'] ?? $defaults['checkout_mode'] );
	$sanitized['product_source'] = sanitize_text_field( $profile['product_source'] ?? $defaults['product_source'] );
	$sanitized['tax_shipping_payment_status'] = sanitize_text_field( $profile['tax_shipping_payment_status'] ?? $defaults['tax_shipping_payment_status'] );
	$sanitized['frontend_url'] = esc_url_raw( $profile['frontend_url'] ?? '' );
	$sanitized['wordpress_site_url'] = esc_url_raw( $profile['wordpress_site_url'] ?? get_option( 'siteurl', '' ) );
	$sanitized['wordpress_api_url'] = esc_url_raw( $profile['wordpress_api_url'] ?? '' );
	$sanitized['woocommerce_api_url'] = esc_url_raw( $profile['woocommerce_api_url'] ?? '' );
	$sanitized['revalidation_secret'] = sanitize_text_field( $profile['revalidation_secret'] ?? '' );
	$sanitized['license_key'] = sanitize_text_field( $profile['license_key'] ?? '' );
	$sanitized['google_analytics'] = sanitize_text_field( $profile['google_analytics'] ?? '' );
	$sanitized['meta_pixel'] = sanitize_text_field( $profile['meta_pixel'] ?? '' );
	$sanitized['search_console'] = sanitize_text_field( $profile['search_console'] ?? '' );
	$sanitized['crm_webhook'] = esc_url_raw( $profile['crm_webhook'] ?? '' );
	$sanitized['email_provider'] = sanitize_text_field( $profile['email_provider'] ?? '' );
	$sanitized['payment_gateway_status'] = sanitize_text_field( $profile['payment_gateway_status'] ?? '' );
	$sanitized['api_credentials_status'] = sanitize_text_field( $profile['api_credentials_status'] ?? '' );
	$sanitized['active_modules'] = array_values(
		array_filter(
			array_map( 'sanitize_key', (array) ( $profile['active_modules'] ?? array() ) )
		)
	);

	return $sanitized;
}

/**
 * Save a deployment profile.
 *
 * @param array<string,mixed> $profile Profile payload.
 * @return bool
 */
function marveo_save_deployment_profile( $profile ) {
	$sanitized = marveo_sanitize_deployment_profile( $profile );
	update_option( 'marveo_deployment_profile', $sanitized );
	update_option( 'marveo_deployment_url', $sanitized['frontend_url'] );

	$validation = marveo_validate_deployment_profile( $sanitized );
	update_option( 'marveo_deployment_status', $validation['status'] );
	update_option( 'marveo_deployment_setup_completed', $validation['setup_completed'] );
	update_option( 'marveo_deployment_validation_passed', $validation['validation_passed'] );
	update_option( 'marveo_deployment_last_validated_at', $validation['last_validated_at'] );

	if ( $validation['setup_completed'] && $validation['validation_passed'] ) {
		marveo_set_connector_status( 'active' );
	} else {
		marveo_set_connector_status( 'pending_setup' );
	}

	return true;
}

/**
 * Validate a deployment profile against mode-specific requirements.
 *
 * @param array<string,mixed>|null $profile Deployment profile.
 * @return array<string,mixed>
 */
function marveo_validate_deployment_profile( $profile = null ) {
	$profile = is_array( $profile ) ? $profile : marveo_get_deployment_profile();
	$mode    = 'headless' === ( $profile['mode'] ?? '' ) ? 'headless' : 'wordpress';
	$missing = array();
	$require_license_key = (bool) apply_filters( 'marveo_connector_require_license_key', false, $profile, $mode );
	$require_wc_credentials = (bool) apply_filters( 'marveo_connector_require_wc_credentials', false, $profile, $mode );

	if ( empty( $profile['business_name'] ) ) {
		$missing[] = 'Business name is required.';
	}

	if ( empty( $profile['contact_email'] ) || ! is_email( $profile['contact_email'] ) ) {
		$missing[] = 'A valid contact email is required.';
	}

	if ( empty( $profile['primary_color'] ) ) {
		$missing[] = 'Primary brand color is required.';
	}

	if ( empty( $profile['secondary_color'] ) ) {
		$missing[] = 'Secondary brand color is required.';
	}

	if ( 'headless' === $mode ) {
		if ( empty( $profile['frontend_url'] ) ) {
			$missing[] = 'Frontend URL is required for headless mode.';
		}

		if ( empty( $profile['wordpress_api_url'] ) ) {
			$missing[] = 'WordPress API URL is required for headless mode.';
		}

		if ( empty( $profile['woocommerce_api_url'] ) ) {
			$missing[] = 'WooCommerce API URL is required for headless mode.';
		}

		$revalidation_secret = ! empty( marveo_get_env_value( 'MARVEO_REVALIDATION_SECRET' ) ) ? marveo_get_env_value( 'MARVEO_REVALIDATION_SECRET' ) : ( $profile['revalidation_secret'] ?? '' );
		if ( empty( $revalidation_secret ) ) {
			$missing[] = 'Revalidation secret must be configured on the server.';
		}
	}

	if ( $require_license_key && empty( marveo_get_env_value( 'LICENSE_KEY' ) ) && empty( $profile['license_key'] ) ) {
		$missing[] = 'License key is required.';
	}

	if ( $require_wc_credentials && 'headless' === $mode && ( empty( marveo_get_env_value( 'WOOCOMMERCE_CONSUMER_KEY' ) ) || empty( marveo_get_env_value( 'WOOCOMMERCE_CONSUMER_SECRET' ) ) ) ) {
		$missing[] = 'WooCommerce API credentials must be configured for headless mode.';
	}

	$setup_completed    = empty( $missing );
	$validation_passed  = $setup_completed;
	$active_modules     = ! empty( $profile['active_modules'] ) && is_array( $profile['active_modules'] ) ? array_values( $profile['active_modules'] ) : array();
	$last_validated_at  = current_time( 'mysql' );
	$status = array(
		'mode'                 => $mode,
		'setup_completed'      => $setup_completed,
		'validation_passed'    => $validation_passed,
		'missing_requirements' => $missing,
		'active_modules'       => $active_modules,
		'client_profile'       => array(
			'business_name'   => (string) ( $profile['business_name'] ?? '' ),
			'industry'        => (string) ( $profile['industry'] ?? '' ),
			'business_model'   => (string) ( $profile['business_model'] ?? '' ),
			'country_currency' => (string) ( $profile['country_currency'] ?? '' ),
			'contact_email'    => (string) ( $profile['contact_email'] ?? '' ),
			'whatsapp_phone'   => (string) ( $profile['whatsapp_phone'] ?? '' ),
		),
		'last_validated_at'    => $last_validated_at,
	);

	return array(
		'setup_completed'    => $setup_completed,
		'validation_passed'  => $validation_passed,
		'missing_requirements' => $missing,
		'last_validated_at'  => $last_validated_at,
		'status'             => $status,
	);
}

/**
 * Get the current deployment status.
 *
 * @return array<string,mixed>
 */
function marveo_get_deployment_status() {
	$status = get_option( 'marveo_deployment_status' );
	if ( is_array( $status ) && ! empty( $status['mode'] ) ) {
		return $status;
	}

	$validation = marveo_validate_deployment_profile();
	update_option( 'marveo_deployment_status', $validation['status'] );
	update_option( 'marveo_deployment_setup_completed', $validation['setup_completed'] );
	update_option( 'marveo_deployment_validation_passed', $validation['validation_passed'] );
	update_option( 'marveo_deployment_last_validated_at', $validation['last_validated_at'] );

	return $validation['status'];
}

/**
 * Check whether deployment setup is complete.
 *
 * @return bool
 */
function marveo_is_deployment_setup_complete() {
	return (bool) get_option( 'marveo_deployment_setup_completed', false );
}

/**
 * Check whether deployment validation has passed.
 *
 * @return bool
 */
function marveo_is_deployment_validation_passed() {
	return (bool) get_option( 'marveo_deployment_validation_passed', false );
}
