<?php
/**
 * Marveo Onboarding System
 *
 * Handles three onboarding paths:
 * 1. NEW BUILD - Fresh Marveo deployment
 * 2. EXISTING WORDPRESS - Connect existing WordPress/WooCommerce
 * 3. EXISTING HEADLESS - Connect existing Next.js frontend
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Marveo_Onboarding {
	const ONBOARDING_PATHS = array(
		'new_build'          => 'New Build',
		'existing_wordpress' => 'Existing WordPress Site',
		'existing_headless'  => 'Existing Headless/Next.js Site',
	);

	const DEPLOYMENT_ARCHITECTURES = array(
		'wordpress_only'      => 'WordPress Only',
		'headless_next_js'    => 'Headless Next.js + WordPress',
		'hybrid'              => 'Hybrid (Gradual Migration)',
		'headless_migration'  => 'Migrate to Headless',
		'frontend_adapter'    => 'Connect Existing Frontend',
		'content_only'        => 'Content Migration Only',
	);

	const MODULES = array(
		'products'        => array( 'name' => 'Products', 'description' => 'WooCommerce products and catalog', 'requires' => array( 'commerce' ) ),
		'blog'            => array( 'name' => 'Blog/News', 'description' => 'Blog posts and news articles', 'requires' => array() ),
		'pages'           => array( 'name' => 'Pages', 'description' => 'Custom pages and landing pages', 'requires' => array() ),
		'solutions'       => array( 'name' => 'Solutions/Services', 'description' => 'Services and solutions pages', 'requires' => array() ),
		'testimonials'    => array( 'name' => 'Testimonials', 'description' => 'Client testimonials and reviews', 'requires' => array() ),
		'case_studies'    => array( 'name' => 'Case Studies', 'description' => 'Case studies and success stories', 'requires' => array() ),
		'landing_pages'   => array( 'name' => 'Landing Pages', 'description' => 'Campaign landing pages', 'requires' => array() ),
		'promotions'      => array( 'name' => 'Promotions/Banners', 'description' => 'Sales banners and promotions', 'requires' => array( 'products' ) ),
		'whatsapp_cta'    => array( 'name' => 'WhatsApp CTA', 'description' => 'WhatsApp call-to-action buttons', 'requires' => array() ),
		'newsletter'      => array( 'name' => 'Newsletter', 'description' => 'Email newsletter subscription', 'requires' => array() ),
		'crm_webhook'     => array( 'name' => 'CRM Integration', 'description' => 'CRM webhook integration', 'requires' => array() ),
		'analytics'       => array( 'name' => 'Analytics', 'description' => 'Site analytics and tracking', 'requires' => array() ),
		'seo'             => array( 'name' => 'SEO', 'description' => 'SEO management and metadata', 'requires' => array() ),
		'b2b_quotation'   => array( 'name' => 'B2B/Quotation', 'description' => 'B2B quotation requests', 'requires' => array() ),
		'multi_location'  => array( 'name' => 'Multi-Location', 'description' => 'Multiple store locations', 'requires' => array() ),
	);

	/**
	 * Get onboarding path options
	 */
	public static function get_onboarding_paths() {
		return self::ONBOARDING_PATHS;
	}

	/**
	 * Get deployment architectures for a given path
	 */
	public static function get_architectures_for_path( $onboarding_path ) {
		$all_architectures = self::DEPLOYMENT_ARCHITECTURES;

		switch ( $onboarding_path ) {
			case 'new_build':
				return array_slice( $all_architectures, 0, 3, true ); // wordpress_only, headless_next_js, hybrid

			case 'existing_wordpress':
				return array(
					'wordpress_only'     => $all_architectures['wordpress_only'],
					'hybrid'             => $all_architectures['hybrid'],
					'headless_migration' => $all_architectures['headless_migration'],
				);

			case 'existing_headless':
				return array(
					'frontend_adapter' => $all_architectures['frontend_adapter'],
					'content_only'     => $all_architectures['content_only'],
				);

			default:
				return array();
		}
	}

	/**
	 * Get all available modules
	 */
	public static function get_modules() {
		return self::MODULES;
	}

	/**
	 * Validate module dependencies
	 */
	public static function validate_modules( $active_modules ) {
		$modules = self::MODULES;
		$errors  = array();

		foreach ( $active_modules as $module ) {
			if ( ! isset( $modules[ $module ] ) ) {
				$errors[] = sprintf( 'Unknown module: %s', $module );
				continue;
			}

			$required = $modules[ $module ]['requires'] ?? array();
			foreach ( $required as $dep ) {
				if ( ! in_array( $dep, $active_modules, true ) ) {
					$errors[] = sprintf( 'Module "%s" requires "%s" to be active', $module, $dep );
				}
			}
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
		);
	}
}
