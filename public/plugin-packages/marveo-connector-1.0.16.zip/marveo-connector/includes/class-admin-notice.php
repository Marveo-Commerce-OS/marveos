<?php
/**
 * Admin Notice class - displays activation notice
 *
 * @package Marveo_Connector
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marveo_Admin_Notice class
 */
class Marveo_Admin_Notice {
	/**
	 * Initialize the admin notice
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_notices', array( __CLASS__, 'display_notice' ) );
	}

	/**
	 * Display admin notice
	 *
	 * @return void
	 */
	public static function display_notice() {
		// Check if user can manage options
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$deployment_status = marveo_get_deployment_status();
		$missing_items     = ! empty( $deployment_status['missing_requirements'] ) && is_array( $deployment_status['missing_requirements'] ) ? $deployment_status['missing_requirements'] : array();

		if ( ! marveo_is_deployment_setup_complete() || ! marveo_is_deployment_validation_passed() ) {
			?>
			<div class="notice notice-warning">
				<p><strong><?php esc_html_e( 'Marvéo deployment setup is incomplete.', 'marveo-connector' ); ?></strong></p>
				<p><?php esc_html_e( 'Complete and validate the deployment profile before treating this site as production-ready.', 'marveo-connector' ); ?></p>
				<?php if ( ! empty( $missing_items ) ) : ?>
					<ul style="margin-left: 20px; list-style: disc;">
						<?php foreach ( $missing_items as $item ) : ?>
							<li><?php echo esc_html( $item ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
			<?php
		}

		// Activation notice remains time-limited and should only appear after activation.
		if ( ! get_transient( 'marveo_activation_notice' ) ) {
			return;
		}

		$token              = get_option( 'marveo_activation_token' );
		$expiry_timestamp   = get_option( 'marveo_activation_token_expires' );
		$deployment_url     = marveo_get_deployment_url();
		$hours_remaining    = intdiv( $expiry_timestamp - current_time( 'timestamp' ), 3600 );

		if ( $hours_remaining < 0 ) {
			$hours_remaining = 0;
		}

		?>
		<div class="notice notice-info is-dismissible">
			<p>
				<strong><?php esc_html_e( 'Marvéo Connector Activated!', 'marveo-connector' ); ?></strong>
			</p>
			<p>
				<?php esc_html_e( 'Your activation token:', 'marveo-connector' ); ?><br>
				<code style="background: #f1f1f1; padding: 8px 12px; border-radius: 4px; display: inline-block; font-weight: bold; margin: 10px 0;">
					<?php echo esc_html( $token ); ?>
				</code>
			</p>
			<p>
				<strong style="color: #d32f2f;">
					<?php
					printf(
						/* translators: %d: hours remaining */
						esc_html__( 'This token expires in %d hours.', 'marveo-connector' ),
						intval( $hours_remaining )
					);
					?>
				</strong>
			</p>
			<?php if ( $deployment_url ) : ?>
				<p>
					<a href="<?php echo esc_url( $deployment_url ); ?>" class="button button-primary" target="_blank">
						<?php esc_html_e( 'Complete Setup in Marvéo', 'marveo-connector' ); ?>
					</a>
				</p>
			<?php else : ?>
				<p>
					<em><?php esc_html_e( 'Configure the Marvéo Deployment URL in settings to see the setup button.', 'marveo-connector' ); ?></em>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}
}
