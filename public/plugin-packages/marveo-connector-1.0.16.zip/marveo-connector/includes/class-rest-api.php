<?php
/**
 * REST API class - handles all REST endpoints
 *
 * @package Marveo_Connector
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marveo_REST_API class
 */
class Marveo_REST_API {
	/**
	 * REST API namespace
	 *
	 * @var string
	 */
	private static $namespace = 'marveo/v1';

	/**
	 * Register REST routes
	 *
	 * @return void
	 */
	public static function register_routes() {
		// GET /status - No auth required for initial check
		register_rest_route(
			self::$namespace,
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_status' ),
				'permission_callback' => '__return_true',
			)
		);

		// GET /site-info - Requires JWT authentication
		register_rest_route(
			self::$namespace,
			'/site-info',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_site_info' ),
				'permission_callback' => array( __CLASS__, 'check_jwt_permission' ),
			)
		);

		// POST /init-admin - Requires activation token
		register_rest_route(
			self::$namespace,
			'/init-admin',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'init_admin' ),
				'permission_callback' => array( __CLASS__, 'check_activation_token' ),
			)
		);
	}

	/**
	 * GET /status endpoint
	 *
	 * @param WP_REST_Request $request REST request object
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_status( $request ) {
		$response = array(
			'status'              => marveo_get_connector_status(),
			'connector_version'   => MARVEO_CONNECTOR_VERSION,
			'site_id'             => marveo_get_site_id(),
			'wordpress_version'   => get_bloginfo( 'version' ),
			'woocommerce_version' => marveo_get_woocommerce_version() ?: null,
			'jwt_enabled'         => marveo_is_jwt_enabled(),
			'first_admin_created'  => get_option( 'marveo_first_admin_created', false ),
			'deployment_status'    => marveo_get_deployment_status(),
			'deployment_profile'   => marveo_get_deployment_profile(),
			'setup_completed'      => marveo_is_deployment_setup_complete(),
			'validation_passed'    => marveo_is_deployment_validation_passed(),
		);

		return rest_ensure_response( $response );
	}

	/**
	 * GET /site-info endpoint
	 *
	 * @param WP_REST_Request $request REST request object
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_site_info( $request ) {
		// Double check JWT permission
		if ( ! self::check_jwt_permission( $request ) ) {
			return new WP_Error(
				'unauthorized',
				__( 'Unauthorized', 'marveo-connector' ),
				array( 'status' => 401 )
			);
		}

		$active_plugins = marveo_get_active_plugins();

		$response = array(
			'site_url'               => get_option( 'siteurl' ),
			'site_name'              => get_bloginfo( 'name' ),
			'admin_email'            => get_option( 'admin_email' ),
			'woocommerce_installed'  => marveo_get_woocommerce_version() ? true : false,
			'active_plugins'         => $active_plugins,
			'multisite'              => is_multisite(),
		);

		return rest_ensure_response( $response );
	}

	/**
	 * POST /init-admin endpoint
	 *
	 * @param WP_REST_Request $request REST request object
	 * @return WP_REST_Response|WP_Error
	 */
	public static function init_admin( $request ) {
		// Get JSON body
		$params = $request->get_json_params();

		// Validate required fields
		if ( ! isset( $params['username'] ) || ! isset( $params['email'] ) || ! isset( $params['password'] ) ) {
			return new WP_Error(
				'missing_fields',
				__( 'Missing required fields: username, email, password', 'marveo-connector' ),
				array( 'status' => 400 )
			);
		}

		$username = marveo_sanitize_username( $params['username'] );
		$email    = marveo_validate_email( $params['email'] );
		$password = $params['password'];

		// Validate email
		if ( ! $email ) {
			return new WP_Error(
				'invalid_email',
				__( 'Invalid email format', 'marveo-connector' ),
				array( 'status' => 400 )
			);
		}

		// Validate username
		if ( empty( $username ) || strlen( $username ) < 3 ) {
			return new WP_Error(
				'invalid_username',
				__( 'Username must be at least 3 characters', 'marveo-connector' ),
				array( 'status' => 400 )
			);
		}

		// Validate password
		if ( empty( $password ) || strlen( $password ) < 8 ) {
			return new WP_Error(
				'weak_password',
				__( 'Password must be at least 8 characters', 'marveo-connector' ),
				array( 'status' => 400 )
			);
		}

		// Check if first admin already created
		if ( get_option( 'marveo_first_admin_created' ) ) {
			return new WP_Error(
				'admin_exists',
				__( 'Marvéo admin user already created', 'marveo-connector' ),
				array( 'status' => 409 )
			);
		}

		// Create or get user
		$user_id = username_exists( $username );

		if ( ! $user_id ) {
			$user_id = wp_create_user( $username, $password, $email );
		}

		if ( is_wp_error( $user_id ) ) {
			return new WP_Error(
				'user_creation_failed',
				$user_id->get_error_message(),
				array( 'status' => 500 )
			);
		}

		// Set user role to Administrator
		if ( is_multisite() ) {
			$user = get_userdata( $user_id );
			$user->add_role( 'administrator' );
		} else {
			$user = new WP_User( $user_id );
			$user->set_role( 'administrator' );
		}

		// Update metadata
		update_option( 'marveo_first_admin_created', true );
		if ( marveo_is_deployment_setup_complete() && marveo_is_deployment_validation_passed() ) {
			marveo_set_connector_status( 'active' );
		} else {
			marveo_set_connector_status( 'pending_setup' );
		}

		// Consume the activation token
		delete_option( 'marveo_activation_token' );
		delete_option( 'marveo_activation_token_expires' );

		// Fire hook
		do_action( 'marveo_first_admin_created', $user_id );

		marveo_log( 'First admin user created. User ID: ' . $user_id );

		return rest_ensure_response(
			array(
				'success' => true,
				'user_id' => $user_id,
				'message' => __( 'Marvéo admin user created successfully', 'marveo-connector' ),
			)
		);
	}

	/**
	 * Check if request has valid JWT token
	 *
	 * @param WP_REST_Request $request REST request object
	 * @return bool|WP_Error
	 */
	public static function check_jwt_permission( $request ) {
		// Check if user is authenticated (JWT or basic auth)
		$user = wp_get_current_user();

		if ( ! $user || ! $user->ID ) {
			return new WP_Error(
				'unauthorized',
				__( 'Unauthorized. Please provide a valid JWT token.', 'marveo-connector' ),
				array( 'status' => 401 )
			);
		}

		// Check if user has required capability
		if ( ! marveo_user_has_capability( $user->ID ) ) {
			return new WP_Error(
				'forbidden',
				__( 'User does not have permission to access Marvéo API', 'marveo-connector' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Check if request has valid activation token
	 *
	 * @param WP_REST_Request $request REST request object
	 * @return bool|WP_Error
	 */
	public static function check_activation_token( $request ) {
		$params = $request->get_json_params();
		$token  = '';

		if ( is_array( $params ) && ! empty( $params['activation_token'] ) ) {
			$token = sanitize_text_field( wp_unslash( $params['activation_token'] ) );
		}

		if ( empty( $token ) ) {
			$token = $request->get_header( 'X-Marveo-Activation-Token' );
		}

		if ( empty( $token ) ) {
			$auth_header = $request->get_header( 'Authorization' );

			if ( ! $auth_header ) {
				return new WP_Error(
					'missing_token',
					__( 'Missing activation token header', 'marveo-connector' ),
					array( 'status' => 401 )
				);
			}

			// Backward compatibility for older clients that still send Bearer TOKEN.
			$parts = explode( ' ', $auth_header );
			if ( count( $parts ) !== 2 || 'Bearer' !== $parts[0] ) {
				return new WP_Error(
					'invalid_token_format',
					__( 'Invalid token format. Use X-Marveo-Activation-Token or "Bearer TOKEN".', 'marveo-connector' ),
					array( 'status' => 401 )
				);
			}

			$token = $parts[1];
		}

		// Validate token
		if ( ! marveo_is_token_valid( $token ) ) {
			return new WP_Error(
				'invalid_or_expired_token',
				__( 'Invalid or expired token', 'marveo-connector' ),
				array( 'status' => 401 )
			);
		}

		return true;
	}
}
