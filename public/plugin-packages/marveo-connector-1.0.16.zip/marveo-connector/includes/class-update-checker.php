<?php
/**
 * Plugin update checker for GitHub-hosted releases/tags.
 *
 * @package Marveo_Connector
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marveo_Update_Checker class.
 */
class Marveo_Update_Checker {
	/**
	 * Canonical plugin basename for all installs.
	 *
	 * @var string
	 */
	private static $canonical_plugin_file = 'marveo-connector/marveo-connector.php';

	/**
	 * Cached remote metadata transient key.
	 *
	 * @var string
	 */
	private static $cache_key = 'marveo_connector_update_meta';

	/**
	 * Initialize update hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject_update' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'plugins_api' ), 10, 3 );
		add_filter( 'upgrader_source_selection', array( __CLASS__, 'fix_package_folder' ), 10, 4 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'clear_cache_after_upgrade' ), 10, 2 );
		add_action( 'load-plugins.php', array( __CLASS__, 'maybe_refresh_update_cache' ) );
		add_action( 'load-update-core.php', array( __CLASS__, 'maybe_refresh_update_cache' ) );
	}

	/**
	 * Refresh plugin update cache on key admin screens when stale.
	 *
	 * @return void
	 */
	public static function maybe_refresh_update_cache() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		$force_refresh = (bool) apply_filters( 'marveo_connector_force_refresh_on_admin_pages', true );
		if ( $force_refresh ) {
			delete_transient( self::$cache_key );
			delete_site_transient( 'update_plugins' );

			if ( function_exists( 'wp_clean_plugins_cache' ) ) {
				wp_clean_plugins_cache( false );
			}

			if ( ! function_exists( 'wp_update_plugins' ) ) {
				require_once ABSPATH . 'wp-includes/update.php';
			}

			wp_update_plugins();
			return;
		}

		$throttle_key = 'marveo_connector_last_update_refresh';
		$last_refresh = (int) get_transient( $throttle_key );
		$interval     = (int) apply_filters( 'marveo_connector_update_refresh_interval', 15 * MINUTE_IN_SECONDS );

		if ( $last_refresh && ( time() - $last_refresh ) < $interval ) {
			return;
		}

		delete_transient( self::$cache_key );
		delete_site_transient( 'update_plugins' );
		set_transient( $throttle_key, time(), $interval );

		if ( ! function_exists( 'wp_update_plugins' ) ) {
			require_once ABSPATH . 'wp-includes/update.php';
		}

		wp_update_plugins();
	}

	/**
	 * Add update info to WordPress plugin updates transient.
	 *
	 * @param object $transient Plugins transient object.
	 * @return object
	 */
	public static function inject_update( $transient ) {
		if ( empty( $transient ) || empty( $transient->checked ) || ! is_object( $transient ) ) {
			return $transient;
		}

		$plugin_file = plugin_basename( MARVEO_CONNECTOR_FILE );
		$current     = MARVEO_CONNECTOR_VERSION;
		$remote      = self::get_remote_metadata();

		if ( empty( $remote['version'] ) ) {
			return $transient;
		}

		if ( version_compare( $remote['version'], $current, '>' ) ) {
			$item              = new stdClass();
			$item->id          = self::project_url();
			$item->slug        = dirname( $plugin_file );
			$item->plugin      = $plugin_file;
			$item->new_version = $remote['version'];
			$item->url         = $remote['details_url'];
			$item->package     = $remote['package_url'];

			$transient->response[ $plugin_file ] = $item;
		} else {
			unset( $transient->response[ $plugin_file ] );
		}

		return $transient;
	}

	/**
	 * Get the currently available update payload for this plugin.
	 *
	 * @return object|null
	 */
	public static function get_available_update() {
		$transient = get_site_transient( 'update_plugins' );
		if ( ! is_object( $transient ) ) {
			$transient = new stdClass();
		}

		$transient   = self::inject_update( $transient );
		$plugin_file = plugin_basename( MARVEO_CONNECTOR_FILE );

		if ( empty( $transient->response[ $plugin_file ] ) || ! is_object( $transient->response[ $plugin_file ] ) ) {
			return null;
		}

		return $transient->response[ $plugin_file ];
	}

	/**
	 * Provide plugin details in the "View details" modal.
	 *
	 * @param false|object|array $res    Result object or array.
	 * @param string             $action Action name.
	 * @param object             $args   Request arguments.
	 * @return false|object
	 */
	public static function plugins_api( $res, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) ) {
			return $res;
		}

		$plugin_slug = dirname( plugin_basename( MARVEO_CONNECTOR_FILE ) );
		if ( $plugin_slug !== $args->slug ) {
			return $res;
		}

		$remote = self::get_remote_metadata();
		if ( empty( $remote['version'] ) ) {
			return $res;
		}

		$info                 = new stdClass();
		$info->name           = 'Marvéo Connector';
		$info->slug           = $plugin_slug;
		$info->version        = $remote['version'];
		$info->author         = '<a href="https://avariodigital.com">Avario Digitals</a>';
		$info->homepage       = self::project_url();
		$info->download_link  = $remote['package_url'];
		$info->requires       = '5.9';
		$info->requires_php   = '7.4';
		$info->last_updated   = $remote['published_at'];
		$info->sections       = array(
			'description' => __( 'Connects your WordPress/WooCommerce store to the Marvéo operations platform.', 'marveo-connector' ),
			'changelog'   => sprintf( '<p>%s</p>', esc_html( $remote['changelog'] ) ),
		);

		return $info;
	}

	/**
	 * Normalize extracted GitHub package folder to the plugin slug.
	 *
	 * @param string $source        Source path.
	 * @param string $remote_source Remote source path.
	 * @param object $upgrader      Upgrader instance.
	 * @param array  $hook_extra    Upgrade context.
	 * @return string|WP_Error
	 */
	public static function fix_package_folder( $source, $remote_source, $upgrader, $hook_extra ) {
		if ( empty( $hook_extra['type'] ) || 'plugin' !== $hook_extra['type'] ) {
			return $source;
		}

		$plugin_file = plugin_basename( MARVEO_CONNECTOR_FILE );
		$targeted    = false;

		if ( ! empty( $hook_extra['plugin'] ) && $hook_extra['plugin'] === $plugin_file ) {
			$targeted = true;
		}

		if ( ! $targeted && ! empty( $hook_extra['plugins'] ) && is_array( $hook_extra['plugins'] ) ) {
			$targeted = in_array( $plugin_file, $hook_extra['plugins'], true );
		}

		if ( ! $targeted ) {
			return $source;
		}

		global $wp_filesystem;
		if ( ! $wp_filesystem ) {
			return $source;
		}

		$desired = trailingslashit( $remote_source ) . dirname( self::$canonical_plugin_file );
		if ( untrailingslashit( $source ) === untrailingslashit( $desired ) ) {
			return $source;
		}

		if ( $wp_filesystem->exists( $desired ) ) {
			$wp_filesystem->delete( $desired, true );
		}

		if ( ! $wp_filesystem->move( $source, $desired, true ) ) {
			return new WP_Error(
				'marveo_update_rename_failed',
				__( 'Could not prepare update package for Marvéo Connector.', 'marveo-connector' )
			);
		}

		return $desired;
	}

	/**
	 * Clear cached metadata after plugin upgrades.
	 *
	 * @param WP_Upgrader $upgrader_object Upgrader object.
	 * @param array       $options         Upgrade options.
	 * @return void
	 */
	public static function clear_cache_after_upgrade( $upgrader_object, $options ) {
		if ( empty( $options['type'] ) || 'plugin' !== $options['type'] ) {
			return;
		}

		if ( empty( $options['plugins'] ) || ! is_array( $options['plugins'] ) ) {
			return;
		}

		$plugin_file = plugin_basename( MARVEO_CONNECTOR_FILE );
		if ( in_array( $plugin_file, $options['plugins'], true ) ) {
			delete_transient( self::$cache_key );
			delete_transient( 'marveo_connector_last_update_refresh' );
			self::repair_active_plugin_basename( $plugin_file );
		}
	}

	/**
	 * Repair active plugin entries to canonical basename after updates.
	 *
	 * @param string $current_plugin_file Running plugin basename.
	 * @return void
	 */
	private static function repair_active_plugin_basename( $current_plugin_file ) {
		if ( ! defined( 'WP_PLUGIN_DIR' ) ) {
			return;
		}

		$canonical_file = self::$canonical_plugin_file;
		$canonical_path = WP_PLUGIN_DIR . '/' . $canonical_file;
		if ( ! file_exists( $canonical_path ) ) {
			return;
		}

		$old_candidates = array( $current_plugin_file );
		$active_plugins = get_option( 'active_plugins', array() );
		if ( is_array( $active_plugins ) ) {
			$updated = false;
			foreach ( $active_plugins as $index => $active_plugin ) {
				if ( in_array( $active_plugin, $old_candidates, true ) || preg_match( '#^marveo-connector-[^/]+/marveo-connector\.php$#', (string) $active_plugin ) ) {
					$active_plugins[ $index ] = $canonical_file;
					$updated                  = true;
				}
			}

			if ( $updated ) {
				$active_plugins = array_values( array_unique( $active_plugins ) );
				update_option( 'active_plugins', $active_plugins );
			}
		}

		$network_plugins = get_site_option( 'active_sitewide_plugins', array() );
		if ( is_array( $network_plugins ) ) {
			$updated = false;
			foreach ( array_keys( $network_plugins ) as $plugin_key ) {
				if ( in_array( $plugin_key, $old_candidates, true ) || preg_match( '#^marveo-connector-[^/]+/marveo-connector\.php$#', (string) $plugin_key ) ) {
					$network_plugins[ $canonical_file ] = $network_plugins[ $plugin_key ];
					unset( $network_plugins[ $plugin_key ] );
					$updated = true;
				}
			}

			if ( $updated ) {
				update_site_option( 'active_sitewide_plugins', $network_plugins );
			}
		}
	}

	/**
	 * Fetch and cache release/tag metadata from GitHub.
	 *
	 * @return array<string,string>
	 */
	private static function get_remote_metadata() {
		$bypass_cache = (bool) apply_filters( 'marveo_connector_bypass_metadata_cache', true );

		if ( ! $bypass_cache ) {
			$cached = get_transient( self::$cache_key );
			if ( is_array( $cached ) && ! empty( $cached['version'] ) ) {
				return $cached;
			}
		}

		$res = wp_remote_get( self::metadata_url(), self::request_args() );
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			return array();
		}

		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $body ) || empty( $body['version'] ) || empty( $body['package_url'] ) ) {
			return array();
		}

		$data = array(
			'version'      => (string) $body['version'],
			'package_url'  => (string) $body['package_url'],
			'details_url'  => ! empty( $body['details_url'] ) ? (string) $body['details_url'] : '',
			'changelog'    => ! empty( $body['changelog'] ) ? wp_strip_all_tags( (string) $body['changelog'] ) : sprintf( 'Version %s', (string) $body['version'] ),
			'published_at' => ! empty( $body['published_at'] ) ? (string) $body['published_at'] : '',
		);

		if ( ! $bypass_cache ) {
			$cache_ttl = (int) apply_filters( 'marveo_connector_update_cache_ttl', 15 * MINUTE_IN_SECONDS );
			set_transient( self::$cache_key, $data, $cache_ttl );
		}
		return $data;
	}

	/**
	 * Request args for remote update calls.
	 *
	 * @return array<string,mixed>
	 */
	private static function request_args() {
		return array(
			'headers' => array(
				'Accept'     => 'application/json',
				'Cache-Control' => 'no-cache, no-store, must-revalidate',
				'Pragma'     => 'no-cache',
				'User-Agent' => 'Marveo-Connector/' . MARVEO_CONNECTOR_VERSION . '; ' . home_url(),
			),
			'timeout' => 15,
		);
	}

	/**
	 * Public update metadata URL.
	 *
	 * @return string
	 */
	private static function metadata_url() {
		$default_url = 'https://marveo-dev.vercel.app/api/plugin-updates/marveo-connector';
		$stored_url  = function_exists( 'marveo_get_update_api_url' ) ? marveo_get_update_api_url() : get_option( 'marveo_update_api_url', '' );
		$env_url     = getenv( 'MARVEO_UPDATE_API_URL' );
		$url         = $stored_url ? $stored_url : ( $env_url ? $env_url : $default_url );
		$bypass_cache = (bool) apply_filters( 'marveo_connector_bypass_metadata_cache', true );

		if ( $bypass_cache ) {
			$url = add_query_arg( 'cache_bust', (string) time(), $url );
		}

		return (string) apply_filters( 'marveo_connector_update_api_url', $url );
	}

	/**
	 * Public project homepage URL.
	 *
	 * @return string
	 */
	private static function project_url() {
		return 'https://github.com/Marveo-Commerce-OS/marveo-connector';
	}
}
