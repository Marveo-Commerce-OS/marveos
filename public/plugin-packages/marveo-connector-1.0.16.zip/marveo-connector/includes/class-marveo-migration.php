<?php
/**
 * MARVEO to Marveo Migration Layer
 *
 * Provides backward compatibility and automatic migration from MARVEO deployments
 * to new Marveo client profile system.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Marveo_Migration {
	/**
	 * Check if site has MARVEO configuration
	 */
	public static function has_marveo_config() {
		$marveo_indicators = array(
			'marveo_central_url',
			'marveo_shop_url',
			'marveo_store_type',
			'marveo_deployment_profile',
			'central_marveo_global',
		);

		foreach ( $marveo_indicators as $option ) {
			if ( get_option( $option ) ) {
				return true;
			}
		}

		// Check for MARVEO-specific post types
		if ( post_type_exists( 'marveo_store' ) || post_type_exists( 'marveo_document' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Migrate MARVEO configuration to Marveo
	 */
	public static function migrate_configuration() {
		$source_config = self::read_marveo_config();

		if ( empty( $source_config ) ) {
			return false;
		}

		$new_config = self::convert_marveo_to_marveo( $source_config );

		// Save new configuration
		update_option( 'marveo_deployment_config', $new_config );
		update_option( 'marveo_migration_status', array(
			'migrated_at'  => current_time( 'mysql' ),
			'source_config'  => $source_config,
			'new_config'   => $new_config,
			'status'       => 'pending_review',
		) );

		return $new_config;
	}

	/**
	 * Read existing MARVEO configuration
	 */
	private static function read_marveo_config() {
		$config = array();

		// Read MARVEO API URLs
		$config['central_url']   = get_option( 'marveo_central_url' ) ?: 'https://central.marveo.global';
		$config['shop_url']      = get_option( 'marveo_shop_url' ) ?: 'https://shop.marveo.global';
		$config['api_key']       = get_option( 'marveo_api_key' );
		$config['store_type']    = get_option( 'marveo_store_type' ) ?: 'marveo';
		$config['business_name'] = get_option( 'marveo_business_name' ) ?: 'MARVEO';
		$config['email']         = get_option( 'marveo_email' ) ?: 'sales@marveo.global';

		return $config;
	}

	/**
	 * Convert MARVEO config to new Marveo format
	 */
	private static function convert_marveo_to_marveo( $marveo_config ) {
		return array(
			'onboarding_path'         => 'existing_wordpress', // Assume existing WP
			'deployment_architecture' => 'wordpress_only', // MARVEO was always WP-based
			'deployment_mode'         => 'wordpress',
			'api_urls'                => array(
				'wordpress'   => $marveo_config['central_url'],
				'woocommerce' => $marveo_config['shop_url'],
			),
			'business_profile'        => array(
				'business_name' => $marveo_config['business_name'],
				'contact_email' => $marveo_config['email'],
			),
			'store_type_mapping'      => array(
				'old' => 'marveo',
				'new' => 'location',
			),
		);
	}

	/**
	 * Migrate MARVEO post types to generic ones
	 */
	public static function migrate_post_types() {
		$migrations = array(
			'marveo_store'    => 'marveo_location',
			'marveo_document' => 'marveo_document',
		);

		foreach ( $migrations as $old_type => $new_type ) {
			self::migrate_post_type( $old_type, $new_type );
		}

		update_option( 'marveo_post_types_migrated', true );
	}

	/**
	 * Migrate individual post type
	 */
	private static function migrate_post_type( $old_type, $new_type ) {
		$posts = get_posts( array(
			'post_type'      => $old_type,
			'posts_per_page' => -1,
		) );

		foreach ( $posts as $post ) {
			// Update post type
			$wpdb = $GLOBALS['wpdb'];
			$wpdb->update(
				$wpdb->posts,
				array( 'post_type' => $new_type ),
				array( 'ID' => $post->ID ),
				array( '%s' ),
				array( '%d' )
			);

			// Update post meta (store_type MARVEO -> location)
			$meta = get_post_meta( $post->ID, 'store_type', true );
			if ( $meta === 'marveo' ) {
				update_post_meta( $post->ID, 'store_type', 'location' );
			}
		}
	}

	/**
	 * Migrate MARVEO settings to new global settings
	 */
	public static function migrate_settings() {
		$marveo_settings = get_option( 'marveo_admin_settings', array() );

		if ( empty( $marveo_settings ) ) {
			return false;
		}

		// Map MARVEO settings to Marveo groups
		$migrations = array(
			'business_profile' => array(
				'business_name'   => $marveo_settings['company_name'] ?? 'MARVEO',
				'contact_email'   => $marveo_settings['email'] ?? 'sales@marveo.global',
				'contact_phone'   => $marveo_settings['phone'] ?? '',
				'business_address' => $marveo_settings['address'] ?? '',
			),
			'brand_settings'   => array(
				'primary_color'   => $marveo_settings['primary_color'] ?? '#FF6B6B',
				'secondary_color' => $marveo_settings['secondary_color'] ?? '#FFD93D',
				'logo'            => $marveo_settings['logo_url'] ?? '',
			),
			'content_settings' => array(
				'homepage_title'    => $marveo_settings['site_title'] ?? 'MARVEO',
				'homepage_subtitle' => $marveo_settings['tagline'] ?? '',
				'mission'           => $marveo_settings['mission'] ?? '',
				'about_content'     => $marveo_settings['about'] ?? '',
			),
		);

		foreach ( $migrations as $group => $settings ) {
			update_option( "marveo_settings_$group", $settings );
		}

		return true;
	}

	/**
	 * Get migration status
	 */
	public static function get_migration_status() {
		return get_option( 'marveo_migration_status', array( 'status' => 'not_started' ) );
	}

	/**
	 * Mark migration as complete
	 */
	public static function complete_migration() {
		$status = self::get_migration_status();
		$status['status'] = 'completed';
		$status['completed_at'] = current_time( 'mysql' );

		update_option( 'marveo_migration_status', $status );

		// Mark deployment as validated
		$profile = marveo_get_deployment_profile();
		$profile['validation_passed'] = true;
		$profile['setup_completed'] = true;
		marveo_save_deployment_profile( $profile );
	}

	/**
	 * Detect MARVEO features used
	 */
	public static function detect_marveo_features() {
		$features = array(
			'stores'    => (int) wp_count_posts( 'marveo_store' )->publish ?? 0,
			'documents' => (int) wp_count_posts( 'marveo_document' )->publish ?? 0,
			'products'  => class_exists( 'WooCommerce' ) ? count( wc_get_products( array( 'return' => 'ids' ) ) ) : 0,
		);

		return $features;
	}

	/**
	 * Create rollback option if migration needs to be undone
	 */
	public static function create_rollback_point() {
		$rollback = array(
			'source_config'       => self::read_marveo_config(),
			'deployment_config'   => get_option( 'marveo_deployment_config' ),
			'created_at'        => current_time( 'mysql' ),
		);

		update_option( 'marveo_migration_rollback', $rollback );
		return $rollback;
	}

	/**
	 * Rollback migration
	 */
	public static function rollback_migration() {
		$rollback = get_option( 'marveo_migration_rollback' );

		if ( ! $rollback ) {
			return false;
		}

		// Restore MARVEO config
		update_option( 'marveo_admin_settings', $rollback['source_config'] );

		// Remove Marveo config
		delete_option( 'marveo_deployment_config' );
		delete_option( 'marveo_migration_status' );

		return true;
	}
}
