<?php
/**
 * Content Discovery for Existing WordPress Sites
 *
 * Scans and catalogs existing WordPress/WooCommerce content
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Marveo_Content_Discovery {
	/**
	 * Scan WordPress site for content inventory
	 */
	public static function scan_site() {
		$inventory = array(
			'pages'             => self::scan_pages(),
			'posts'             => self::scan_posts(),
			'woocommerce'       => self::scan_woocommerce(),
			'menus'             => self::scan_menus(),
			'media'             => self::scan_media(),
			'special_pages'     => self::detect_special_pages(),
			'seo_metadata'      => self::scan_seo_metadata(),
			'total_count'       => 0,
			'scanned_at'        => current_time( 'mysql' ),
		);

		// Calculate total
		$inventory['total_count'] = array_sum( array(
			count( $inventory['pages'] ),
			count( $inventory['posts'] ),
			count( $inventory['woocommerce']['products'] ?? array() ),
			count( $inventory['menus'] ),
			count( $inventory['media'] ),
		) );

		return $inventory;
	}

	/**
	 * Scan pages
	 */
	private static function scan_pages() {
		$pages = get_posts( array(
			'post_type'      => 'page',
			'posts_per_page' => -1,
			'post_status'    => array( 'publish', 'draft' ),
			'orderby'        => 'menu_order',
		) );

		return array_map( function( $page ) {
			return array(
				'id'           => $page->ID,
				'title'        => $page->post_title,
				'slug'         => $page->post_name,
				'status'       => $page->post_status,
				'parent_id'    => $page->post_parent,
				'excerpt'      => wp_strip_all_tags( $page->post_excerpt ),
				'has_featured' => has_post_thumbnail( $page->ID ),
				'modified'     => $page->post_modified,
			);
		}, $pages );
	}

	/**
	 * Scan posts
	 */
	private static function scan_posts() {
		$posts = get_posts( array(
			'post_type'      => 'post',
			'posts_per_page' => -1,
			'post_status'    => array( 'publish', 'draft' ),
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );

		return array_map( function( $post ) {
			$categories = wp_get_post_terms( $post->ID, 'category', array( 'fields' => 'names' ) );
			return array(
				'id'           => $post->ID,
				'title'        => $post->post_title,
				'slug'         => $post->post_name,
				'status'       => $post->post_status,
				'date'         => $post->post_date,
				'excerpt'      => wp_strip_all_tags( $post->post_excerpt ),
				'categories'   => $categories ?? array(),
				'has_featured' => has_post_thumbnail( $post->ID ),
				'author'       => get_the_author_meta( 'display_name', $post->post_author ),
			);
		}, $posts );
	}

	/**
	 * Scan WooCommerce products and categories
	 */
	private static function scan_woocommerce() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return array( 'enabled' => false );
		}

		$products = wc_get_products( array(
			'limit'  => -1,
			'status' => array( 'publish', 'draft' ),
			'return' => 'objects',
		) );

		$categories = get_terms( array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
		) );

		return array(
			'enabled'    => true,
			'products'   => array_map( function( $product ) {
				$category_names = array();
				$category_ids = $product->get_category_ids();
				if ( is_array( $category_ids ) ) {
					foreach ( $category_ids as $category_id ) {
						$term = get_term( $category_id, 'product_cat' );
						if ( $term && ! is_wp_error( $term ) ) {
							$category_names[] = $term->name;
						}
					}
				}

				return array(
					'id'           => $product->get_id(),
					'name'         => $product->get_name(),
					'sku'          => $product->get_sku(),
					'type'         => $product->get_type(),
					'price'        => $product->get_price(),
					'status'       => $product->get_status(),
					'has_image'    => $product->get_image_id() > 0,
					'categories'   => $category_names,
					'in_stock'     => $product->is_in_stock(),
				);
			}, $products ),
			'categories' => array_map( function( $cat ) {
				return array(
					'id'    => $cat->term_id,
					'name'  => $cat->name,
					'slug'  => $cat->slug,
					'count' => $cat->count,
				);
			}, $categories ),
			'total_products' => count( $products ),
		);
	}

	/**
	 * Scan menus
	 */
	private static function scan_menus() {
		$menus = wp_get_nav_menus();
		return array_map( function( $menu ) {
			$items = wp_get_nav_menu_items( $menu->term_id );
			return array(
				'id'     => $menu->term_id,
				'name'   => $menu->name,
				'slug'   => $menu->slug,
				'count'  => $menu->count,
				'items'  => is_array( $items ) ? count( $items ) : 0,
			);
		}, $menus );
	}

	/**
	 * Scan media
	 */
	private static function scan_media() {
		$attachments = get_posts( array(
			'post_type'      => 'attachment',
			'posts_per_page' => -1,
			'post_status'    => 'inherit',
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );

		$by_type = array(
			'images'       => 0,
			'documents'    => 0,
			'videos'       => 0,
			'audio'        => 0,
			'other'        => 0,
		);

		foreach ( $attachments as $attachment ) {
			$mime = $attachment->post_mime_type;
			if ( strpos( $mime, 'image' ) === 0 ) {
				$by_type['images']++;
			} elseif ( strpos( $mime, 'video' ) === 0 ) {
				$by_type['videos']++;
			} elseif ( strpos( $mime, 'audio' ) === 0 ) {
				$by_type['audio']++;
			} elseif ( in_array( $mime, array( 'application/pdf', 'application/msword' ), true ) ) {
				$by_type['documents']++;
			} else {
				$by_type['other']++;
			}
		}

		return array_merge( $by_type, array( 'total' => count( $attachments ) ) );
	}

	/**
	 * Detect special pages (home, about, contact, blog, shop, etc.)
	 */
	private static function detect_special_pages() {
		$detected = array();

		// Homepage
		$homepage_id = get_option( 'page_on_front' );
		if ( $homepage_id ) {
			$detected['homepage'] = array(
				'id'    => $homepage_id,
				'title' => get_the_title( $homepage_id ),
				'url'   => get_permalink( $homepage_id ),
			);
		}

		// Blog page
		$blog_id = get_option( 'page_for_posts' );
		if ( $blog_id ) {
			$detected['blog'] = array(
				'id'    => $blog_id,
				'title' => get_the_title( $blog_id ),
				'url'   => get_permalink( $blog_id ),
			);
		}

		// Shop page (WooCommerce)
		if ( class_exists( 'WooCommerce' ) ) {
			$shop_id = wc_get_page_id( 'shop' );
			if ( $shop_id ) {
				$detected['shop'] = array(
					'id'    => $shop_id,
					'title' => get_the_title( $shop_id ),
					'url'   => get_permalink( $shop_id ),
				);
			}
		}

		// Try to find common pages by slug
		$common_slugs = array( 'about', 'contact', 'services', 'solutions', 'faq', 'privacy', 'terms' );
		foreach ( $common_slugs as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page ) {
				$detected[ $slug ] = array(
					'id'    => $page->ID,
					'title' => $page->post_title,
					'url'   => get_permalink( $page->ID ),
				);
			}
		}

		return $detected;
	}

	/**
	 * Scan SEO metadata (if Yoast or similar is installed)
	 */
	private static function scan_seo_metadata() {
		$seo_info = array(
			'yoast_installed'  => function_exists( 'wpseo_get_value' ),
			'rank_math_installed' => function_exists( 'rank_math' ),
			'pages_with_focus_keyword' => 0,
			'pages_with_meta_description' => 0,
		);

		// Count pages with Yoast meta data
		if ( $seo_info['yoast_installed'] ) {
			$pages = get_posts( array( 'post_type' => 'page', 'posts_per_page' => -1 ) );
			foreach ( $pages as $page ) {
				$focus = wpseo_get_value( 'focuskw', $page->ID );
				$meta  = wpseo_get_value( 'metadesc', $page->ID );
				if ( $focus ) {
					$seo_info['pages_with_focus_keyword']++;
				}
				if ( $meta ) {
					$seo_info['pages_with_meta_description']++;
				}
			}
		}

		return $seo_info;
	}

	/**
	 * Save content inventory
	 */
	public static function save_inventory( $inventory ) {
		update_option( 'marveo_content_inventory', $inventory );
		return true;
	}

	/**
	 * Get cached inventory
	 */
	public static function get_inventory() {
		return get_option( 'marveo_content_inventory', array() );
	}
}
