<?php
/**
 * Admin Page class - settings page in WordPress admin
 *
 * @package Marveo_Connector
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marveo_Admin_Page class
 */
class Marveo_Admin_Page {
	/**
	 * Add menu to WordPress admin
	 *
	 * @return void
	 */
	public static function add_menu() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		add_menu_page(
			__( 'Marvéo Connector', 'marveo-connector' ),
			__( 'Marvéo', 'marveo-connector' ),
			'manage_options',
			'marveo-connector',
			array( __CLASS__, 'render_page' ),
			'dashicons-admin-generic',
			26
		);

		add_submenu_page(
			'marveo-connector',
			__( 'Connection Status', 'marveo-connector' ),
			__( 'Connection Status', 'marveo-connector' ),
			'manage_options',
			'marveo-connection-status',
			array( __CLASS__, 'render_connection_status_page' )
		);

		add_submenu_page(
			'marveo-connector',
			__( 'Sync Status', 'marveo-connector' ),
			__( 'Sync Status', 'marveo-connector' ),
			'manage_options',
			'marveo-sync-status',
			array( __CLASS__, 'render_sync_status_page' )
		);

		add_submenu_page(
			'marveo-connector',
			__( 'Diagnostics', 'marveo-connector' ),
			__( 'Diagnostics', 'marveo-connector' ),
			'manage_options',
			'marveo-diagnostics',
			array( __CLASS__, 'render_diagnostics_page' )
		);

		add_submenu_page(
			'marveo-connector',
			__( 'Content Mapping', 'marveo-connector' ),
			__( 'Content Mapping', 'marveo-connector' ),
			'manage_options',
			'marveo-content-mapping',
			array( __CLASS__, 'render_content_mapping_page' )
		);

		add_submenu_page(
			'marveo-connector',
			__( 'Runtime Logs', 'marveo-connector' ),
			__( 'Runtime Logs', 'marveo-connector' ),
			'manage_options',
			'marveo-runtime-logs',
			array( __CLASS__, 'render_runtime_logs_page' )
		);

		add_submenu_page(
			'marveo-connector',
			__( 'Emergency Tools', 'marveo-connector' ),
			__( 'Emergency Tools', 'marveo-connector' ),
			'manage_options',
			'marveo-emergency-tools',
			array( __CLASS__, 'render_emergency_tools_page' )
		);

		add_submenu_page(
			'marveo-connector',
			__( 'Open Marveo Cloud', 'marveo-connector' ),
			__( 'Open Marveo Cloud', 'marveo-connector' ),
			'manage_options',
			'marveo-open-cloud',
			array( __CLASS__, 'render_open_cloud_page' )
		);
	}

	/**
	 * Render the settings page
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'marveo-connector' ) );
		}

		// Handle form submissions
		self::handle_form_submission();

		$status                 = marveo_get_connector_status();
		$site_id                = marveo_get_site_id();
		$token                  = get_option( 'marveo_activation_token' );
		$expiry                 = get_option( 'marveo_activation_token_expires' );
		$first_admin_created    = get_option( 'marveo_first_admin_created' );
		$deployment_url         = marveo_get_deployment_url();
		$deployment_profile     = marveo_get_deployment_profile();
		$deployment_status      = marveo_get_deployment_status();
		$command_token          = (string) get_option( 'marveo_command_token', '' );
		$command_token_masked   = '';
		$wordpress_version      = get_bloginfo( 'version' );
		$woocommerce_version    = marveo_get_woocommerce_version();
		$jwt_enabled            = marveo_is_jwt_enabled();
		$available_update       = Marveo_Update_Checker::get_available_update();
		$hours_remaining        = intdiv( $expiry - current_time( 'timestamp' ), 3600 );

		if ( '' !== $command_token ) {
			$command_token_masked = str_repeat( '*', max( 0, strlen( $command_token ) - 6 ) ) . substr( $command_token, -6 );
		}

		if ( $hours_remaining < 0 ) {
			$hours_remaining = 0;
		}

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Marvéo Connector', 'marveo-connector' ); ?></h1>
			<hr class="wp-header-end">
			<?php settings_errors( 'marveo_connector' ); ?>

			<?php self::render_deployment_setup_section( $deployment_profile, $deployment_status ); ?>

			<?php if ( $available_update ) : ?>
				<div class="notice notice-info" style="margin: 15px 0 20px;">
					<p>
						<strong><?php esc_html_e( 'New version available.', 'marveo-connector' ); ?></strong>
						<?php
						echo ' ' . esc_html(
							sprintf(
								/* translators: 1: current version, 2: available version */
								__( 'You are running %1$s and version %2$s is ready to install.', 'marveo-connector' ),
								MARVEO_CONNECTOR_VERSION,
								$available_update->new_version
							)
						);
						?>
						<a href="<?php echo esc_url( admin_url( 'update-core.php' ) ); ?>"><?php esc_html_e( 'Go to WordPress Updates', 'marveo-connector' ); ?></a>
					</p>
				</div>
			<?php endif; ?>

			<?php self::render_status_section( $status, $site_id, $first_admin_created ); ?>

			<div class="postbox">
				<h2 class="hndle"><span><?php esc_html_e( 'Connector Information', 'marveo-connector' ); ?></span></h2>
				<div class="inside">
					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'Connector Status', 'marveo-connector' ); ?></th>
							<td>
								<strong>
									<?php
									if ( 'active' === $status ) {
										echo '<span style="color: #28a745;">● ' . esc_html__( 'Active', 'marveo-connector' ) . '</span>';
									} elseif ( 'pending_setup' === $status ) {
										echo '<span style="color: #ffc107;">● ' . esc_html__( 'Pending Setup', 'marveo-connector' ) . '</span>';
									} else {
										echo '<span style="color: #dc3545;">● ' . esc_html__( 'Disconnected', 'marveo-connector' ) . '</span>';
									}
									?>
								</strong>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Site ID', 'marveo-connector' ); ?></th>
							<td><code><?php echo esc_html( $site_id ); ?></code></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'WordPress Version', 'marveo-connector' ); ?></th>
							<td><?php echo esc_html( $wordpress_version ); ?></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'WooCommerce Status', 'marveo-connector' ); ?></th>
							<td>
								<?php
								if ( $woocommerce_version ) {
									echo esc_html( $woocommerce_version );
								} else {
									echo '<span style="color: #dc3545;">' . esc_html__( 'Not installed', 'marveo-connector' ) . '</span>';
								}
								?>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'JWT Auth Status', 'marveo-connector' ); ?></th>
							<td>
								<?php
								if ( $jwt_enabled ) {
									echo '<span style="color: #28a745;">✓ ' . esc_html__( 'Enabled', 'marveo-connector' ) . '</span>';
								} else {
									echo '<span style="color: #dc3545;">✗ ' . esc_html__( 'Not installed', 'marveo-connector' ) . '</span>';
								}
								?>
							</td>
						</tr>
					</table>
				</div>
			</div>

			<div class="postbox">
				<h2 class="hndle"><span><?php esc_html_e( 'Activation Token', 'marveo-connector' ); ?></span></h2>
				<div class="inside">
					<?php if ( $token && $expiry > current_time( 'timestamp' ) ) : ?>
						<p>
							<strong><?php esc_html_e( 'Current Token (expires in ' . intval( $hours_remaining ) . ' hours):', 'marveo-connector' ); ?></strong><br>
							<code style="background: #f1f1f1; padding: 8px 12px; border-radius: 4px; display: inline-block; margin: 10px 0;">
								<?php echo esc_html( $token ); ?>
							</code>
						</p>
					<?php else : ?>
						<p><em><?php esc_html_e( 'No valid token available. Regenerate to create a new one.', 'marveo-connector' ); ?></em></p>
					<?php endif; ?>

					<form method="post" style="margin-top: 15px;">
						<?php wp_nonce_field( 'marveo_regenerate_token', 'marveo_nonce' ); ?>
						<button type="submit" name="marveo_action" value="regenerate_token" class="button button-secondary">
							<?php esc_html_e( 'Regenerate Token', 'marveo-connector' ); ?>
						</button>
					</form>
				</div>
			</div>

			<div class="postbox">
				<h2 class="hndle"><span><?php esc_html_e( 'Marvéo Configuration', 'marveo-connector' ); ?></span></h2>
				<div class="inside">
					<form method="post">
						<input type="hidden" name="marveo_action" value="save_settings">
						<?php wp_nonce_field( 'marveo_settings', 'marveo_nonce' ); ?>
						<table class="form-table">
							<tr>
								<th>
									<label for="marveo_deployment_url"><?php esc_html_e( 'Marvéo Deployment URL', 'marveo-connector' ); ?></label>
								</th>
								<td>
									<input type="url" id="marveo_deployment_url" name="marveo_deployment_url" value="<?php echo esc_url( $deployment_url ); ?>" class="regular-text" placeholder="https://app.marveo.com/...">
									<p class="description"><?php esc_html_e( 'The URL to your Marvéo instance setup page', 'marveo-connector' ); ?></p>
								</td>
							</tr>
								<tr>
									<th>
										<label for="marveo_update_api_url"><?php esc_html_e( 'Marvéo Update API URL', 'marveo-connector' ); ?></label>
									</th>
									<td>
										<input type="url" id="marveo_update_api_url" name="marveo_update_api_url" value="<?php echo esc_url( marveo_get_update_api_url() ); ?>" class="regular-text" placeholder="https://your-live-deployment.vercel.app/api/plugin-updates/marveo-connector">
										<p class="description"><?php esc_html_e( 'The public endpoint the plugin uses to check for updates.', 'marveo-connector' ); ?></p>
									</td>
								</tr>
									<tr>
										<th>
											<label for="marveo_command_token"><?php esc_html_e( 'Command Token', 'marveo-connector' ); ?></label>
										</th>
										<td>
											<input type="password" id="marveo_command_token" name="marveo_command_token" value="" class="regular-text" placeholder="Paste or set a command token">
											<?php if ( '' !== $command_token_masked ) : ?>
												<p class="description">
													<?php esc_html_e( 'Saved token', 'marveo-connector' ); ?>:
													<code><?php echo esc_html( $command_token_masked ); ?></code>
												</p>
											<?php endif; ?>
											<p class="description"><?php esc_html_e( 'Used by cloud command endpoints when no admin session is present.', 'marveo-connector' ); ?></p>
										</td>
									</tr>
						</table>
						<?php submit_button( __( 'Save Settings', 'marveo-connector' ) ); ?>
					</form>

						<form method="post" style="margin-top:8px;">
							<?php wp_nonce_field( 'marveo_rotate_command_token', 'marveo_nonce' ); ?>
							<button type="submit" name="marveo_action" value="rotate_command_token" class="button button-secondary">
								<?php esc_html_e( 'Rotate Command Token', 'marveo-connector' ); ?>
							</button>
						</form>

						<form method="post" style="margin-top:8px;">
							<?php wp_nonce_field( 'marveo_refresh_plugin_updates', 'marveo_nonce' ); ?>
							<button type="submit" name="marveo_action" value="refresh_plugin_updates" class="button button-secondary">
								<?php esc_html_e( 'Force Refresh Updates', 'marveo-connector' ); ?>
							</button>
						</form>
				</div>
			</div>

			<?php if ( 'active' === $status ) : ?>
				<div class="postbox">
					<h2 class="hndle"><span><?php esc_html_e( 'Danger Zone', 'marveo-connector' ); ?></span></h2>
					<div class="inside">
						<p><?php esc_html_e( 'Disconnect this WordPress installation from Marvéo. This will reset all Marvéo settings and require re-setup.', 'marveo-connector' ); ?></p>
						<form method="post" onsubmit="return confirm('<?php esc_html_e( 'Are you sure you want to disconnect from Marvéo?', 'marveo-connector' ); ?>');">
							<?php wp_nonce_field( 'marveo_disconnect', 'marveo_nonce' ); ?>
							<button type="submit" name="marveo_action" value="disconnect" class="button button-primary" style="background-color: #dc3545; border-color: #dc3545;">
								<?php esc_html_e( 'Disconnect from Marvéo', 'marveo-connector' ); ?>
							</button>
						</form>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render the deployment setup wizard.
	 *
	 * @param array<string,mixed> $profile Deployment profile.
	 * @param array<string,mixed> $status  Deployment status.
	 * @return void
	 */
	private static function render_deployment_setup_section( $profile, $status ) {
		$missing = ! empty( $status['missing_requirements'] ) && is_array( $status['missing_requirements'] ) ? $status['missing_requirements'] : array();
		$modules = array(
			'products' => 'Products',
			'categories' => 'Categories',
			'blog_news' => 'Blog/News',
			'solutions_services' => 'Solutions/Services',
			'testimonials' => 'Testimonials',
			'case_studies' => 'Case Studies',
			'landing_pages' => 'Landing Pages',
			'promotions_banners' => 'Promotions/Banners',
			'whatsapp_cta' => 'WhatsApp CTA',
			'newsletter' => 'Newsletter',
			'crm_webhook' => 'CRM/Webhook',
			'analytics' => 'Analytics',
			'seo' => 'SEO',
			'b2b_quotation' => 'B2B/Quotation',
			'multi_location' => 'Multi-location',
		);
		?>
		<div class="postbox" style="margin-bottom: 20px;">
			<h2 class="hndle"><span><?php esc_html_e( 'Deployment Setup Wizard', 'marveo-connector' ); ?></span></h2>
			<div class="inside">
				<p>
					<strong><?php esc_html_e( 'Deployment profile must be selected, validated, and saved before this site is considered ready.', 'marveo-connector' ); ?></strong>
				</p>
				<p>
					<?php
					printf(
						/* translators: 1: mode, 2: validation state */
						esc_html__( 'Current mode: %1$s | Validation: %2$s', 'marveo-connector' ),
						esc_html( ucfirst( (string) ( $status['mode'] ?? 'wordpress' ) ) ),
						! empty( $status['validation_passed'] ) ? esc_html__( 'Passed', 'marveo-connector' ) : esc_html__( 'Pending', 'marveo-connector' )
					);
					?>
				</p>
				<?php if ( ! empty( $missing ) ) : ?>
					<div class="notice notice-warning inline" style="margin: 10px 0 20px;">
						<p><strong><?php esc_html_e( 'Missing requirements:', 'marveo-connector' ); ?></strong></p>
						<ul style="margin-left: 20px; list-style: disc;">
							<?php foreach ( $missing as $item ) : ?>
								<li><?php echo esc_html( $item ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>
				<form method="post">
					<input type="hidden" name="marveo_action" value="save_deployment_profile">
					<?php wp_nonce_field( 'marveo_deployment_profile', 'marveo_nonce' ); ?>

					<h3>1. Deployment Type</h3>
					<p>
						<label><input type="radio" name="deployment_profile[mode]" value="headless" <?php checked( ( $profile['mode'] ?? 'wordpress' ), 'headless' ); ?>> Headless WordPress + Next.js</label><br>
						<label><input type="radio" name="deployment_profile[mode]" value="wordpress" <?php checked( ( $profile['mode'] ?? 'wordpress' ), 'wordpress' ); ?>> WordPress Only</label>
					</p>

					<h3>2. Business Profile</h3>
					<table class="form-table">
						<tr><th>Business name</th><td><input class="regular-text" name="deployment_profile[business_name]" value="<?php echo esc_attr( $profile['business_name'] ?? '' ); ?>"></td></tr>
						<tr><th>Industry</th><td><input class="regular-text" name="deployment_profile[industry]" value="<?php echo esc_attr( $profile['industry'] ?? '' ); ?>"></td></tr>
						<tr><th>Business model</th><td><select name="deployment_profile[business_model]"><option <?php selected( $profile['business_model'] ?? '', 'B2C' ); ?>>B2C</option><option <?php selected( $profile['business_model'] ?? '', 'B2B' ); ?>>B2B</option><option <?php selected( $profile['business_model'] ?? '', 'Hybrid' ); ?>>Hybrid</option><option <?php selected( $profile['business_model'] ?? '', 'Catalogue Only' ); ?>>Catalogue Only</option><option <?php selected( $profile['business_model'] ?? '', 'Enquiry Only' ); ?>>Enquiry Only</option></select></td></tr>
						<tr><th>Country / currency</th><td><input class="regular-text" name="deployment_profile[country_currency]" value="<?php echo esc_attr( $profile['country_currency'] ?? '' ); ?>" placeholder="USD / Nigeria / GBP"></td></tr>
						<tr><th>Contact email</th><td><input type="email" class="regular-text" name="deployment_profile[contact_email]" value="<?php echo esc_attr( $profile['contact_email'] ?? '' ); ?>"></td></tr>
						<tr><th>WhatsApp / phone</th><td><input class="regular-text" name="deployment_profile[whatsapp_phone]" value="<?php echo esc_attr( $profile['whatsapp_phone'] ?? '' ); ?>"></td></tr>
					</table>

					<h3>3. Brand Settings</h3>
					<table class="form-table">
						<tr><th>Logo</th><td><input class="regular-text" name="deployment_profile[logo]" value="<?php echo esc_attr( $profile['logo'] ?? '' ); ?>"></td></tr>
						<tr><th>Favicon</th><td><input class="regular-text" name="deployment_profile[favicon]" value="<?php echo esc_attr( $profile['favicon'] ?? '' ); ?>"></td></tr>
						<tr><th>Primary color</th><td><input type="color" name="deployment_profile[primary_color]" value="<?php echo esc_attr( $profile['primary_color'] ?? '#14B8A6' ); ?>"></td></tr>
						<tr><th>Secondary color</th><td><input type="color" name="deployment_profile[secondary_color]" value="<?php echo esc_attr( $profile['secondary_color'] ?? '#A3E635' ); ?>"></td></tr>
						<tr><th>Typography</th><td><input class="regular-text" name="deployment_profile[typography]" value="<?php echo esc_attr( $profile['typography'] ?? 'Inter' ); ?>"></td></tr>
						<tr><th>Header/footer style</th><td><input class="regular-text" name="deployment_profile[header_footer_style]" value="<?php echo esc_attr( $profile['header_footer_style'] ?? 'Standard' ); ?>"></td></tr>
					</table>

					<h3>4. Commerce Settings</h3>
					<table class="form-table">
						<tr><th>WooCommerce enabled?</th><td><label><input type="checkbox" name="deployment_profile[woocommerce_enabled]" value="1" <?php checked( ! empty( $profile['woocommerce_enabled'] ) ); ?>> Yes</label></td></tr>
						<tr><th>Checkout mode</th><td><select name="deployment_profile[checkout_mode]"><option <?php selected( $profile['checkout_mode'] ?? '', 'Native WooCommerce' ); ?>>Native WooCommerce</option><option <?php selected( $profile['checkout_mode'] ?? '', 'External checkout' ); ?>>External checkout</option><option <?php selected( $profile['checkout_mode'] ?? '', 'Enquiry only' ); ?>>Enquiry only</option><option <?php selected( $profile['checkout_mode'] ?? '', 'Quote request' ); ?>>Quote request</option></select></td></tr>
						<tr><th>Product source</th><td><select name="deployment_profile[product_source]"><option <?php selected( $profile['product_source'] ?? '', 'WooCommerce' ); ?>>WooCommerce</option><option <?php selected( $profile['product_source'] ?? '', 'Custom post type' ); ?>>Custom post type</option><option <?php selected( $profile['product_source'] ?? '', 'External API' ); ?>>External API</option></select></td></tr>
						<tr><th>Tax / shipping / payment</th><td><input class="regular-text" name="deployment_profile[tax_shipping_payment_status]" value="<?php echo esc_attr( $profile['tax_shipping_payment_status'] ?? 'unchecked' ); ?>" placeholder="checked / pending / disabled"></td></tr>
					</table>

					<h3>5. Module Selection</h3>
					<div class="columns-2" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 16px;">
						<?php foreach ( $modules as $module_key => $module_label ) : ?>
							<label><input type="checkbox" name="deployment_profile[active_modules][]" value="<?php echo esc_attr( $module_key ); ?>" <?php checked( in_array( $module_key, (array) ( $profile['active_modules'] ?? array() ), true ) ); ?>> <?php echo esc_html( $module_label ); ?></label>
						<?php endforeach; ?>
					</div>

					<h3>6. Integration Settings</h3>
					<table class="form-table">
						<tr><th>Google Analytics</th><td><input class="regular-text" name="deployment_profile[google_analytics]" value="<?php echo esc_attr( $profile['google_analytics'] ?? '' ); ?>"></td></tr>
						<tr><th>Meta Pixel</th><td><input class="regular-text" name="deployment_profile[meta_pixel]" value="<?php echo esc_attr( $profile['meta_pixel'] ?? '' ); ?>"></td></tr>
						<tr><th>Search Console</th><td><input class="regular-text" name="deployment_profile[search_console]" value="<?php echo esc_attr( $profile['search_console'] ?? '' ); ?>"></td></tr>
						<tr><th>CRM webhook</th><td><input class="regular-text" name="deployment_profile[crm_webhook]" value="<?php echo esc_attr( $profile['crm_webhook'] ?? '' ); ?>"></td></tr>
						<tr><th>Email provider</th><td><input class="regular-text" name="deployment_profile[email_provider]" value="<?php echo esc_attr( $profile['email_provider'] ?? '' ); ?>"></td></tr>
						<tr><th>Payment gateway status</th><td><input class="regular-text" name="deployment_profile[payment_gateway_status]" value="<?php echo esc_attr( $profile['payment_gateway_status'] ?? '' ); ?>"></td></tr>
						<tr><th>API credentials status</th><td><input class="regular-text" name="deployment_profile[api_credentials_status]" value="<?php echo esc_attr( $profile['api_credentials_status'] ?? '' ); ?>"></td></tr>
					</table>

					<h3>7. Deployment Validation</h3>
					<p><?php esc_html_e( 'Saving this profile will validate the deployment requirements and only mark the site ready if all requirements pass.', 'marveo-connector' ); ?></p>
					<table class="form-table">
						<tr><th>Frontend URL</th><td><input type="url" class="regular-text" name="deployment_profile[frontend_url]" value="<?php echo esc_attr( $profile['frontend_url'] ?? '' ); ?>" placeholder="https://app.example.com"></td></tr>
						<tr><th>WordPress API URL</th><td><input type="url" class="regular-text" name="deployment_profile[wordpress_api_url]" value="<?php echo esc_attr( $profile['wordpress_api_url'] ?? '' ); ?>" placeholder="https://cms.example.com/wp-json"></td></tr>
						<tr><th>WooCommerce API URL</th><td><input type="url" class="regular-text" name="deployment_profile[woocommerce_api_url]" value="<?php echo esc_attr( $profile['woocommerce_api_url'] ?? '' ); ?>" placeholder="https://cms.example.com/wp-json"></td></tr>
						<tr><th>Revalidation secret</th><td><input type="password" class="regular-text" name="deployment_profile[revalidation_secret]" value="<?php echo esc_attr( $profile['revalidation_secret'] ?? '' ); ?>" autocomplete="off"></td></tr>
						<tr><th>License key</th><td><input class="regular-text" name="deployment_profile[license_key]" value="<?php echo esc_attr( $profile['license_key'] ?? '' ); ?>"></td></tr>
					</table>

					<?php submit_button( __( 'Save Deployment Profile', 'marveo-connector' ), 'primary', 'submit', false ); ?>
				</form>
			</div>
		</div>
		<?php
	}

	/**
	 * Render status section
	 *
	 * @param string $status Connector status
	 * @param string $site_id Site ID
	 * @param bool   $first_admin_created Is first admin created
	 * @return void
	 */
	private static function render_status_section( $status, $site_id, $first_admin_created ) {
		$color = 'pending_setup' === $status ? '#ffc107' : ( 'active' === $status ? '#28a745' : '#dc3545' );
		?>
		<div style="background: <?php echo esc_attr( $color ); ?>; color: white; padding: 20px; border-radius: 4px; margin-bottom: 20px;">
			<h2 style="margin-top: 0; color: white;"><?php esc_html_e( 'Status Overview', 'marveo-connector' ); ?></h2>
			<p>
				<?php
				if ( 'pending_setup' === $status ) {
					esc_html_e( 'Marvéo Connector is installed and waiting to be set up. Use your activation token to complete the setup process.', 'marveo-connector' );
				} elseif ( 'active' === $status ) {
					esc_html_e( 'Marvéo Connector is active and ready to sync data with Marvéo.', 'marveo-connector' );
				} else {
					esc_html_e( 'Marvéo Connector is disconnected. Reactivate or reinstall to reconnect.', 'marveo-connector' );
				}
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Handle form submissions
	 *
	 * @return void
	 */
	private static function handle_form_submission() {
		if ( ! isset( $_POST['marveo_action'] ) || ! isset( $_POST['marveo_nonce'] ) ) {
			return;
		}

		$action = sanitize_key( wp_unslash( $_POST['marveo_action'] ) );
		$nonce  = sanitize_text_field( wp_unslash( $_POST['marveo_nonce'] ) );

		$nonce_action = 'marveo_settings';
		if ( 'regenerate_token' === $action ) {
			$nonce_action = 'marveo_regenerate_token';
		} elseif ( 'disconnect' === $action ) {
			$nonce_action = 'marveo_disconnect';
		} elseif ( 'save_deployment_profile' === $action ) {
			$nonce_action = 'marveo_deployment_profile';
		} elseif ( 'rotate_command_token' === $action ) {
			$nonce_action = 'marveo_rotate_command_token';
		} elseif ( 'refresh_plugin_updates' === $action ) {
			$nonce_action = 'marveo_refresh_plugin_updates';
		}

		if ( ! wp_verify_nonce( $nonce, $nonce_action ) ) {
			wp_die( esc_html__( 'Security check failed.', 'marveo-connector' ) );
		}

		if ( 'regenerate_token' === $action ) {
			self::handle_regenerate_token();
		} elseif ( 'disconnect' === $action ) {
			self::handle_disconnect();
		} elseif ( 'save_deployment_profile' === $action ) {
			self::handle_deployment_profile_save();
		} elseif ( 'rotate_command_token' === $action ) {
			self::handle_rotate_command_token();
		} elseif ( 'refresh_plugin_updates' === $action ) {
			self::handle_refresh_plugin_updates();
		} elseif ( 'save_settings' === $action ) {
			// Handle settings form
			self::handle_settings_save();
		}
	}

	/**
	 * Handle deployment profile save.
	 *
	 * @return void
	 */
	private static function handle_deployment_profile_save() {
		$profile = isset( $_POST['deployment_profile'] ) ? wp_unslash( $_POST['deployment_profile'] ) : array();
		if ( ! is_array( $profile ) ) {
			$profile = array();
		}

		marveo_save_deployment_profile( $profile );
		$validation = marveo_validate_deployment_profile( marveo_get_deployment_profile() );

		if ( $validation['validation_passed'] ) {
			add_settings_error( 'marveo_connector', 'deployment_saved', __( 'Deployment profile saved and validated.', 'marveo-connector' ), 'updated' );
		} else {
			add_settings_error( 'marveo_connector', 'deployment_incomplete', __( 'Deployment profile saved, but validation is still incomplete.', 'marveo-connector' ), 'error' );
		}

		marveo_log( 'Deployment profile updated' );
	}

	/**
	 * Handle token regeneration
	 *
	 * @return void
	 */
	private static function handle_regenerate_token() {
		$token = marveo_generate_token();
		$expiry_time = marveo_get_token_expiry();

		update_option( 'marveo_activation_token', $token );
		update_option( 'marveo_activation_token_expires', current_time( 'timestamp' ) + $expiry_time );

		add_action( 'admin_notices', function() {
			?>
			<div class="notice notice-success is-dismissible">
				<p><?php esc_html_e( 'Activation token regenerated successfully!', 'marveo-connector' ); ?></p>
			</div>
			<?php
		});

		marveo_log( 'Token regenerated' );
	}

	/**
	 * Handle disconnect
	 *
	 * @return void
	 */
	private static function handle_disconnect() {
		marveo_set_connector_status( 'disconnected' );
		delete_option( 'marveo_activation_token' );
		delete_option( 'marveo_activation_token_expires' );
		delete_option( 'marveo_first_admin_created' );

		add_action( 'admin_notices', function() {
			?>
			<div class="notice notice-warning is-dismissible">
				<p><?php esc_html_e( 'Marvéo Connector has been disconnected. You can reactivate it anytime.', 'marveo-connector' ); ?></p>
			</div>
			<?php
		});

		marveo_log( 'Plugin disconnected from Marvéo' );
	}

	/**
	 * Handle settings save
	 *
	 * @return void
	 */
	private static function handle_settings_save() {
		$deployment_url = isset( $_POST['marveo_deployment_url'] ) ? sanitize_url( wp_unslash( $_POST['marveo_deployment_url'] ) ) : '';
		$update_api_url = isset( $_POST['marveo_update_api_url'] ) ? sanitize_url( wp_unslash( $_POST['marveo_update_api_url'] ) ) : '';
		$command_token  = isset( $_POST['marveo_command_token'] ) ? sanitize_text_field( wp_unslash( $_POST['marveo_command_token'] ) ) : '';

		update_option( 'marveo_deployment_url', $deployment_url );
		update_option( 'marveo_update_api_url', $update_api_url );
		if ( '' !== $command_token ) {
			update_option( 'marveo_command_token', $command_token );
		}

		add_action( 'admin_notices', function() {
			?>
			<div class="notice notice-success is-dismissible">
				<p><?php esc_html_e( 'Settings saved successfully!', 'marveo-connector' ); ?></p>
			</div>
			<?php
		});

		marveo_log( 'Settings updated' );
	}

	/**
	 * Handle command token rotation.
	 *
	 * @return void
	 */
	private static function handle_rotate_command_token() {
		$new_token = wp_generate_password( 48, false, false );
		update_option( 'marveo_command_token', $new_token );

		add_action( 'admin_notices', function() {
			?>
			<div class="notice notice-success is-dismissible">
				<p><?php esc_html_e( 'Command token rotated successfully.', 'marveo-connector' ); ?></p>
			</div>
			<?php
		});

		marveo_log( 'Command token rotated' );
	}

	/**
	 * Force-refresh plugin update metadata and WordPress plugin update cache.
	 *
	 * @return void
	 */
	private static function handle_refresh_plugin_updates() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			add_settings_error( 'marveo_connector', 'refresh_updates_forbidden', __( 'You do not have permission to refresh plugin updates.', 'marveo-connector' ), 'error' );
			return;
		}

		delete_transient( 'marveo_connector_update_meta' );
		delete_transient( 'marveo_connector_last_update_refresh' );
		delete_site_transient( 'update_plugins' );

		if ( function_exists( 'wp_clean_plugins_cache' ) ) {
			wp_clean_plugins_cache( false );
		}

		if ( ! function_exists( 'wp_update_plugins' ) ) {
			require_once ABSPATH . 'wp-includes/update.php';
		}

		wp_update_plugins();
		$available_update = Marveo_Update_Checker::get_available_update();

		if ( $available_update && ! empty( $available_update->new_version ) ) {
			add_settings_error(
				'marveo_connector',
				'refresh_updates_success',
				sprintf(
					/* translators: %s: available plugin version */
					__( 'Update metadata refreshed. New version detected: %s.', 'marveo-connector' ),
					esc_html( (string) $available_update->new_version )
				),
				'updated'
			);
		} else {
			add_settings_error( 'marveo_connector', 'refresh_updates_no_update', __( 'Update metadata refreshed. No newer plugin version is currently available.', 'marveo-connector' ), 'updated' );
		}

		marveo_log( 'Plugin update metadata force-refreshed' );
	}

	/**
	 * Render connection status page.
	 *
	 * @return void
	 */
	public static function render_connection_status_page() {
		$status = marveo_get_connector_status();
		$site_id = marveo_get_site_id();
		self::render_operational_page(
			__( 'Connection Status', 'marveo-connector' ),
			array(
				__( 'Connector status', 'marveo-connector' ) => $status,
				__( 'Site ID', 'marveo-connector' ) => $site_id,
				__( 'Deployment URL', 'marveo-connector' ) => marveo_get_deployment_url(),
			)
		);
	}

	/**
	 * Render sync status page.
	 *
	 * @return void
	 */
	public static function render_sync_status_page() {
		$deployment_status = marveo_get_deployment_status();
		self::render_operational_page(
			__( 'Sync Status', 'marveo-connector' ),
			array(
				__( 'Validation passed', 'marveo-connector' ) => ! empty( $deployment_status['validation_passed'] ) ? 'yes' : 'no',
				__( 'Setup completed', 'marveo-connector' ) => ! empty( $deployment_status['setup_completed'] ) ? 'yes' : 'no',
				__( 'Active modules', 'marveo-connector' ) => implode( ', ', (array) ( $deployment_status['active_modules'] ?? array() ) ),
			)
		);
	}

	/**
	 * Render diagnostics page.
	 *
	 * @return void
	 */
	public static function render_diagnostics_page() {
		$deployment_status = marveo_get_deployment_status();
		$missing = isset( $deployment_status['missing_requirements'] ) && is_array( $deployment_status['missing_requirements'] ) ? implode( '; ', $deployment_status['missing_requirements'] ) : '';
		self::render_operational_page(
			__( 'Diagnostics', 'marveo-connector' ),
			array(
				__( 'WordPress version', 'marveo-connector' ) => get_bloginfo( 'version' ),
				__( 'WooCommerce version', 'marveo-connector' ) => marveo_get_woocommerce_version() ?: 'not installed',
				__( 'Missing requirements', 'marveo-connector' ) => $missing ?: 'none',
			)
		);
	}

	/**
	 * Render content mapping page.
	 *
	 * @return void
	 */
	public static function render_content_mapping_page() {
		$inventory = Marveo_Content_Discovery::get_inventory();
		$total = isset( $inventory['total_count'] ) ? (string) $inventory['total_count'] : '0';
		self::render_operational_page(
			__( 'Content Mapping', 'marveo-connector' ),
			array(
				__( 'Scanned content items', 'marveo-connector' ) => $total,
				__( 'Last scan', 'marveo-connector' ) => $inventory['scanned_at'] ?? 'not scanned',
			)
		);
	}

	/**
	 * Render runtime logs page.
	 *
	 * @return void
	 */
	public static function render_runtime_logs_page() {
		$logs = get_option( 'marveo_runtime_logs', array() );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Runtime Logs', 'marveo-connector' ) . '</h1>';
		echo '<p>' . esc_html__( 'Recent connector runtime events. Most recent appears first.', 'marveo-connector' ) . '</p>';
		echo '<div style="background:#fff;border:1px solid #dcdcde;padding:12px;max-width:1000px;">';
		if ( empty( $logs ) ) {
			echo '<p>' . esc_html__( 'No logs available yet.', 'marveo-connector' ) . '</p>';
		} else {
			echo '<ol style="margin:0 0 0 20px;">';
			foreach ( array_reverse( array_slice( $logs, -100 ) ) as $entry ) {
				echo '<li><code>' . esc_html( (string) $entry ) . '</code></li>';
			}
			echo '</ol>';
		}
		echo '</div></div>';
	}

	/**
	 * Render emergency tools page.
	 *
	 * @return void
	 */
	public static function render_emergency_tools_page() {
		self::render_operational_page(
			__( 'Emergency Tools', 'marveo-connector' ),
			array(
				__( 'Reset action', 'marveo-connector' ) => __( 'Use the main Marveo page to regenerate token or disconnect safely.', 'marveo-connector' ),
				__( 'Cloud handoff', 'marveo-connector' ) => __( 'Operational recovery should be coordinated from Marveo Cloud.', 'marveo-connector' ),
			)
		);
	}

	/**
	 * Render cloud redirect page.
	 *
	 * @return void
	 */
	public static function render_open_cloud_page() {
		$cloud_url = marveo_get_deployment_url();
		if ( empty( $cloud_url ) ) {
			$cloud_url = 'https://app.getmarveo.com';
		}

		wp_safe_redirect( esc_url_raw( $cloud_url ) );
		exit;
	}

	/**
	 * Shared renderer for lightweight operational pages.
	 *
	 * @param string $title Page title.
	 * @param array<string,string> $rows Key value rows.
	 * @return void
	 */
	private static function render_operational_page( $title, $rows ) {
		echo '<div class="wrap">';
		echo '<h1>' . esc_html( $title ) . '</h1>';
		echo '<p>' . esc_html__( 'Marveo Cloud is the primary control plane. This page is a local runtime view only.', 'marveo-connector' ) . '</p>';
		echo '<table class="widefat striped" style="max-width:1000px;">';
		echo '<tbody>';
		foreach ( $rows as $key => $value ) {
			echo '<tr><th style="width:260px;">' . esc_html( $key ) . '</th><td>' . esc_html( (string) $value ) . '</td></tr>';
		}
		echo '</tbody></table>';
		echo '<p style="margin-top:16px;"><a class="button button-primary" href="' . esc_url( 'https://app.getmarveo.com' ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open Marveo Cloud', 'marveo-connector' ) . '</a></p>';
		echo '</div>';
	}
}
