<?php
/**
 * Global Settings Schema
 *
 * Structured settings groups for Marveo deployments
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Marveo_Settings_Schema {
	/**
	 * Get all settings groups
	 */
	public static function get_settings_groups() {
		return array(
			'site_settings'   => self::site_settings_schema(),
			'business_profile' => self::business_profile_schema(),
			'brand_settings'   => self::brand_settings_schema(),
			'content_settings' => self::content_settings_schema(),
			'commerce_settings' => self::commerce_settings_schema(),
			'seo_settings'     => self::seo_settings_schema(),
			'module_settings'  => self::module_settings_schema(),
			'integration_settings' => self::integration_settings_schema(),
			'advanced_settings' => self::advanced_settings_schema(),
		);
	}

	/**
	 * Unified site settings used by the Marveo dashboard Settings screen.
	 */
	private static function site_settings_schema() {
		return array(
			'name'        => 'Site Settings',
			'description' => 'Unified settings payload for all Settings tabs in Marveo dashboard',
			'access'      => 'client',
			'fields'      => array(
				'logo_url'                  => array( 'type' => 'text', 'label' => 'Logo URL' ),
				'favicon_url'               => array( 'type' => 'text', 'label' => 'Favicon URL' ),
				'primary_color'             => array( 'type' => 'color', 'label' => 'Primary Color', 'default' => '#14B8A6' ),
				'secondary_color'           => array( 'type' => 'color', 'label' => 'Secondary Color', 'default' => '#A3E635' ),
				'typography'                => array( 'type' => 'text', 'label' => 'Typography' ),
				'socials'                   => array( 'type' => 'object', 'label' => 'Social links' ),
				'payment_gateways'          => array( 'type' => 'array', 'label' => 'Payment gateways' ),
				'integrations'              => array( 'type' => 'array', 'label' => 'Integrations' ),
				'seo_site_title'            => array( 'type' => 'text', 'label' => 'SEO site title' ),
				'seo_meta_description'      => array( 'type' => 'textarea', 'label' => 'SEO meta description' ),
				'seo_keywords'              => array( 'type' => 'text', 'label' => 'SEO keywords' ),
				'custom_head_scripts'       => array( 'type' => 'textarea', 'label' => 'Custom head scripts' ),
				'custom_body_scripts'       => array( 'type' => 'textarea', 'label' => 'Custom body scripts' ),
				'google_analytics_id'       => array( 'type' => 'text', 'label' => 'Google Analytics ID' ),
				'google_search_console_id'  => array( 'type' => 'text', 'label' => 'Google Search Console ID' ),
				'team_members'              => array( 'type' => 'array', 'label' => 'Team members' ),
				'wordpress_users'           => array( 'type' => 'array', 'label' => 'WordPress users' ),
				'module_preferences'        => array( 'type' => 'array', 'label' => 'Module preferences' ),
				'maintenance'               => array( 'type' => 'object', 'label' => 'Maintenance settings' ),
			),
		);
	}

	/**
	 * Business Profile Settings
	 */
	private static function business_profile_schema() {
		return array(
			'name'        => 'Business Profile',
			'description' => 'Core business information',
			'access'      => 'client',
			'fields'      => array(
				'business_name'     => array( 'type' => 'text', 'label' => 'Business Name', 'required' => true ),
				'industry'          => array( 'type' => 'select', 'label' => 'Industry', 'options' => array( 'retail', 'b2b', 'services', 'other' ) ),
				'business_model'    => array( 'type' => 'select', 'label' => 'Business Model', 'options' => array( 'B2C', 'B2B', 'Hybrid', 'Catalogue Only', 'Enquiry Only' ) ),
				'country_currency'  => array( 'type' => 'select', 'label' => 'Country/Currency', 'required' => true ),
				'contact_email'     => array( 'type' => 'email', 'label' => 'Contact Email', 'required' => true ),
				'contact_phone'     => array( 'type' => 'tel', 'label' => 'Contact Phone' ),
				'whatsapp_phone'    => array( 'type' => 'tel', 'label' => 'WhatsApp Phone' ),
				'business_address'  => array( 'type' => 'textarea', 'label' => 'Business Address' ),
				'business_hours'    => array( 'type' => 'textarea', 'label' => 'Business Hours' ),
			),
		);
	}

	/**
	 * Brand Settings
	 */
	private static function brand_settings_schema() {
		return array(
			'name'        => 'Brand Settings',
			'description' => 'Logo, colors, typography, and visual identity',
			'access'      => 'client',
			'fields'      => array(
				'logo'              => array( 'type' => 'media', 'label' => 'Logo' ),
				'favicon'           => array( 'type' => 'media', 'label' => 'Favicon' ),
				'primary_color'     => array( 'type' => 'color', 'label' => 'Primary Color', 'default' => '#14B8A6' ),
				'secondary_color'   => array( 'type' => 'color', 'label' => 'Secondary Color', 'default' => '#A3E635' ),
				'typography'        => array( 'type' => 'select', 'label' => 'Typography', 'options' => array( 'Inter', 'Poppins', 'Playfair Display', 'Open Sans' ) ),
				'header_style'      => array( 'type' => 'select', 'label' => 'Header Style', 'options' => array( 'Standard', 'Minimal', 'With Banner', 'Sticky' ) ),
				'footer_style'      => array( 'type' => 'select', 'label' => 'Footer Style', 'options' => array( 'Standard', 'Minimal', 'Extended', 'Newsletter Focused' ) ),
				'layout_mode'       => array( 'type' => 'select', 'label' => 'Layout Mode', 'options' => array( 'Full Width', 'Boxed', 'Grid' ) ),
			),
		);
	}

	/**
	 * Content Settings
	 */
	private static function content_settings_schema() {
		return array(
			'name'        => 'Content Settings',
			'description' => 'Homepage, about, contact, and general content',
			'access'      => 'client',
			'fields'      => array(
				'homepage_title'    => array( 'type' => 'text', 'label' => 'Homepage Title' ),
				'homepage_subtitle' => array( 'type' => 'textarea', 'label' => 'Homepage Subtitle' ),
				'about_title'       => array( 'type' => 'text', 'label' => 'About Page Title' ),
				'about_content'     => array( 'type' => 'editor', 'label' => 'About Content' ),
				'mission'           => array( 'type' => 'textarea', 'label' => 'Mission Statement' ),
				'vision'            => array( 'type' => 'textarea', 'label' => 'Vision Statement' ),
				'values'            => array( 'type' => 'textarea', 'label' => 'Core Values' ),
				'social_links'      => array( 'type' => 'repeater', 'label' => 'Social Links' ),
				'testimonials'      => array( 'type' => 'repeater', 'label' => 'Testimonials' ),
				'banner_text'       => array( 'type' => 'textarea', 'label' => 'Main Banner Text' ),
				'cta_text'          => array( 'type' => 'text', 'label' => 'Primary CTA Text' ),
			),
		);
	}

	/**
	 * Commerce Settings
	 */
	private static function commerce_settings_schema() {
		return array(
			'name'        => 'Commerce Settings',
			'description' => 'E-commerce configuration',
			'access'      => 'client',
			'fields'      => array(
				'woocommerce_enabled' => array( 'type' => 'checkbox', 'label' => 'Enable WooCommerce' ),
				'checkout_mode'      => array( 'type' => 'select', 'label' => 'Checkout Mode', 'options' => array( 'Native WooCommerce', 'External Checkout', 'Enquiry Only', 'Quote Request' ) ),
				'product_source'     => array( 'type' => 'select', 'label' => 'Product Source', 'options' => array( 'WooCommerce', 'Custom Post Type', 'External API' ) ),
				'currency'           => array( 'type' => 'text', 'label' => 'Currency Code' ),
				'tax_status'         => array( 'type' => 'text', 'label' => 'Tax Configuration' ),
				'shipping_info'      => array( 'type' => 'textarea', 'label' => 'Shipping Information' ),
				'payment_methods'    => array( 'type' => 'textarea', 'label' => 'Accepted Payment Methods' ),
			),
		);
	}

	/**
	 * SEO Settings
	 */
	private static function seo_settings_schema() {
		return array(
			'name'        => 'SEO Settings',
			'description' => 'Search engine optimization configuration',
			'access'      => 'client',
			'fields'      => array(
				'site_title'        => array( 'type' => 'text', 'label' => 'Site Title' ),
				'site_description'  => array( 'type' => 'textarea', 'label' => 'Site Description' ),
				'site_keywords'     => array( 'type' => 'text', 'label' => 'Site Keywords' ),
				'google_analytics'  => array( 'type' => 'text', 'label' => 'Google Analytics ID' ),
				'google_search_console' => array( 'type' => 'text', 'label' => 'Google Search Console Verification' ),
				'meta_pixel'        => array( 'type' => 'text', 'label' => 'Meta Pixel ID' ),
				'robots_txt'        => array( 'type' => 'textarea', 'label' => 'Robots.txt Content' ),
				'sitemap_enabled'   => array( 'type' => 'checkbox', 'label' => 'Enable XML Sitemap' ),
			),
		);
	}

	/**
	 * Module Settings
	 */
	private static function module_settings_schema() {
		return array(
			'name'        => 'Module Settings',
			'description' => 'Enable/disable features and modules',
			'access'      => 'system',
			'fields'      => array(
				'active_modules'    => array( 'type' => 'checkbox_group', 'label' => 'Active Modules' ),
				'feature_flags'     => array( 'type' => 'checkbox_group', 'label' => 'Feature Flags' ),
			),
		);
	}

	/**
	 * Integration Settings
	 */
	private static function integration_settings_schema() {
		return array(
			'name'        => 'Integration Settings',
			'description' => 'CRM, email, webhooks, and third-party integrations',
			'access'      => 'system',
			'fields'      => array(
				'crm_webhook_url'   => array( 'type' => 'text', 'label' => 'CRM Webhook URL', 'secure' => true ),
				'email_provider'    => array( 'type' => 'select', 'label' => 'Email Provider', 'options' => array( 'WordPress', 'SendGrid', 'Mailgun', 'AWS SES' ) ),
				'email_api_key'     => array( 'type' => 'password', 'label' => 'Email API Key', 'secure' => true ),
				'slack_webhook'     => array( 'type' => 'text', 'label' => 'Slack Webhook URL', 'secure' => true ),
				'custom_webhooks'   => array( 'type' => 'repeater', 'label' => 'Custom Webhooks' ),
			),
		);
	}

	/**
	 * Advanced Settings
	 */
	private static function advanced_settings_schema() {
		return array(
			'name'        => 'Advanced Settings',
			'description' => 'System configuration and security',
			'access'      => 'system',
			'fields'      => array(
				'deployment_mode'         => array( 'type' => 'select', 'label' => 'Deployment Mode', 'options' => array( 'wordpress', 'headless', 'hybrid' ), 'locked' => true ),
				'onboarding_path'         => array( 'type' => 'select', 'label' => 'Onboarding Path', 'locked' => true ),
				'deployment_architecture' => array( 'type' => 'select', 'label' => 'Deployment Architecture', 'locked' => true ),
				'frontend_url'            => array( 'type' => 'url', 'label' => 'Frontend URL' ),
				'api_url'                 => array( 'type' => 'url', 'label' => 'API URL', 'locked' => true ),
				'revalidation_secret'     => array( 'type' => 'password', 'label' => 'Revalidation Secret', 'secure' => true, 'locked' => true ),
				'license_key'             => array( 'type' => 'password', 'label' => 'License Key', 'secure' => true, 'locked' => true ),
				'update_channel'          => array( 'type' => 'select', 'label' => 'Update Channel', 'options' => array( 'stable', 'beta', 'development' ) ),
				'debug_mode'              => array( 'type' => 'checkbox', 'label' => 'Enable Debug Mode' ),
			),
		);
	}

	/**
	 * Get settings by access level
	 */
	public static function get_settings_by_access( $access_level ) {
		$groups = self::get_settings_groups();
		return array_filter( $groups, function( $group ) use ( $access_level ) {
			return isset( $group['access'] ) && $group['access'] === $access_level;
		} );
	}
}
