<?php
/**
 * Hooks class - sets up placeholder hooks for future sync
 *
 * @package Marveo_Connector
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marveo_Hooks class
 */
class Marveo_Hooks {
	/**
	 * Initialize hooks
	 *
	 * @return void
	 */
	public static function init() {
		// User hooks - placeholder for future sync
		add_action( 'user_register', array( __CLASS__, 'on_user_register' ), 10, 1 );
		add_action( 'profile_update', array( __CLASS__, 'on_profile_update' ), 10, 2 );
		add_action( 'delete_user', array( __CLASS__, 'on_delete_user' ), 10, 1 );
		add_action( 'set_user_role', array( __CLASS__, 'on_set_user_role' ), 10, 3 );

		// WooCommerce hooks - placeholder for future sync
		if ( class_exists( 'WooCommerce' ) ) {
			add_action( 'woocommerce_payment_complete', array( __CLASS__, 'on_payment_complete' ), 10, 1 );
			add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'on_order_status_changed' ), 10, 3 );
			add_action( 'woocommerce_product_updated', array( __CLASS__, 'on_product_updated' ), 10, 1 );
		}
	}

	/**
	 * Handle user registration
	 *
	 * PLACEHOLDER: Actual sync logic will be implemented in Phase 2
	 *
	 * @param int $user_id User ID
	 * @return void
	 */
	public static function on_user_register( $user_id ) {
		// Future: Sync user data to Marvéo via API
		// $user_data = get_userdata( $user_id );
		// $sync_result = wp_remote_post( ... );
		marveo_log( "User registered: {$user_id}" );

		// Placeholder hook for extensions
		do_action( 'marveo_user_synced', $user_id, array() );
	}

	/**
	 * Handle profile update
	 *
	 * PLACEHOLDER: Actual sync logic will be implemented in Phase 2
	 *
	 * @param int   $user_id User ID
	 * @param array $old_userdata Old user data (deprecated)
	 * @return void
	 */
	public static function on_profile_update( $user_id, $old_userdata = null ) {
		// Future: Sync updated user data to Marvéo
		marveo_log( "User profile updated: {$user_id}" );

		// Placeholder hook for extensions
		do_action( 'marveo_user_synced', $user_id, array() );
	}

	/**
	 * Handle user deletion
	 *
	 * PLACEHOLDER: Actual sync logic will be implemented in Phase 2
	 *
	 * @param int $user_id User ID
	 * @return void
	 */
	public static function on_delete_user( $user_id ) {
		// Future: Sync user deletion to Marvéo
		marveo_log( "User deleted: {$user_id}" );

		// Placeholder hook for extensions
		do_action( 'marveo_user_deleted', $user_id );
	}

	/**
	 * Handle user role change
	 *
	 * PLACEHOLDER: Actual sync logic will be implemented in Phase 2
	 *
	 * @param int    $user_id User ID
	 * @param string $role New role
	 * @param array  $old_roles Old roles
	 * @return void
	 */
	public static function on_set_user_role( $user_id, $role, $old_roles = array() ) {
		// Future: Sync role change to Marvéo
		marveo_log( "User role changed: {$user_id} -> {$role}" );

		// Placeholder hook for extensions
		do_action( 'marveo_user_role_changed', $user_id, $role, $old_roles );
	}

	/**
	 * Handle payment completion
	 *
	 * PLACEHOLDER: Actual sync logic will be implemented in Phase 3
	 *
	 * @param int $order_id WooCommerce order ID
	 * @return void
	 */
	public static function on_payment_complete( $order_id ) {
		// Future: Sync completed order payment to Marvéo
		// $order = wc_get_order( $order_id );
		// $order_data = [ ... ];
		// wp_remote_post( ... );
		marveo_log( "Order payment completed: {$order_id}" );

		// Placeholder hook for extensions
		do_action( 'marveo_order_synced', $order_id, array() );
	}

	/**
	 * Handle order status change
	 *
	 * PLACEHOLDER: Actual sync logic will be implemented in Phase 3
	 *
	 * @param int    $order_id WooCommerce order ID
	 * @param string $old_status Old order status
	 * @param string $new_status New order status
	 * @return void
	 */
	public static function on_order_status_changed( $order_id, $old_status, $new_status ) {
		// Future: Sync order status change to Marvéo
		marveo_log( "Order status changed: {$order_id} -> {$new_status}" );

		// Placeholder hook for extensions
		do_action( 'marveo_order_status_changed', $order_id, $old_status, $new_status );
	}

	/**
	 * Handle product update
	 *
	 * PLACEHOLDER: Actual sync logic will be implemented in Phase 3
	 *
	 * @param int $product_id WooCommerce product ID
	 * @return void
	 */
	public static function on_product_updated( $product_id ) {
		// Future: Sync updated product data to Marvéo
		// $product = wc_get_product( $product_id );
		// $product_data = [ ... ];
		// wp_remote_post( ... );
		marveo_log( "Product updated: {$product_id}" );

		// Placeholder hook for extensions
		do_action( 'marveo_product_synced', $product_id, array() );
	}
}
