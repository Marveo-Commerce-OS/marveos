<?php
/**
 * Enhanced REST API Endpoints for Marveo Connector
 *
 * Adds endpoints for:
 * - Content discovery
 * - Deployment configuration
 * - Settings management
 * - Module management
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Marveo_REST_API_Extended {
	/**
	 * Register REST routes
	 */
	public static function register_routes() {
		// Core runtime endpoints consumed by Marveo Cloud and dynamic frontends.
		register_rest_route( 'marveo/v1', '/site-profile', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_site_profile' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/settings', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_public_settings' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/brand', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_brand' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/pages', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_pages' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/navigation', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_navigation' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/components', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_components' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/products', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_products' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/blog', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_blog' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/seo', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_seo' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/deployment-status', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_deployment_status_payload' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/content-mapping', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'save_content_mapping' ),
			'permission_callback' => array( __CLASS__, 'check_command_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/modules/activate', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'activate_modules' ),
			'permission_callback' => array( __CLASS__, 'check_command_permission' ),
		) );

		// Content Discovery
		register_rest_route( 'marveo/v1', '/content-inventory', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_content_inventory' ),
			'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/content-scan', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'perform_content_scan' ),
			'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
		) );

		// Deployment Configuration
		register_rest_route( 'marveo/v1', '/deployment-config', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_deployment_config' ),
			'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/deployment-config', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'save_deployment_config' ),
			'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
		) );

		// Settings Management
		register_rest_route( 'marveo/v1', '/settings/(?P<group>[a-z_]+)', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_settings_group' ),
			'permission_callback' => array( __CLASS__, 'check_permission_for_group' ),
			'args'                => array(
				'group' => array( 'required' => true ),
			),
		) );

		register_rest_route( 'marveo/v1', '/settings/(?P<group>[a-z_]+)', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'save_settings_group' ),
			'permission_callback' => array( __CLASS__, 'check_permission_for_group' ),
			'args'                => array(
				'group' => array( 'required' => true ),
			),
		) );

		// Modules
		register_rest_route( 'marveo/v1', '/modules', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_modules' ),
			'permission_callback' => array( __CLASS__, 'check_runtime_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/modules/validate', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'validate_modules' ),
			'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
		) );

		// Onboarding
		register_rest_route( 'marveo/v1', '/onboarding/paths', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_onboarding_paths' ),
			'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
		) );

		register_rest_route( 'marveo/v1', '/onboarding/architectures', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'get_architectures' ),
			'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
		) );
	}

	/**
	 * Build a deployment safety object with validations and recovery guidance.
	 *
	 * @return array<string,mixed>
	 */
	private static function build_deployment_status_payload() {
		$status = marveo_get_deployment_status();
		$missing = isset( $status['missing_requirements'] ) && is_array( $status['missing_requirements'] ) ? $status['missing_requirements'] : array();

		$validation_states = array(
			'onboarding_complete'  => (bool) ( $status['setup_completed'] ?? false ),
			'architecture_valid'   => ! empty( $status['mode'] ),
			'api_reachable'        => ! empty( $status['client_profile']['contact_email'] ),
			'modules_valid'        => is_array( $status['active_modules'] ?? null ),
			'frontend_validated'   => (bool) ( $status['validation_passed'] ?? false ),
			'content_mapped'       => empty( $missing ),
			'integrations_configured' => empty( $missing ),
		);

		$recovery_suggestions = array();
		foreach ( $missing as $item ) {
			$recovery_suggestions[] = array(
				'missing'     => (string) $item,
				'suggestion'  => 'Update the deployment profile in Marveo Cloud, then retry validation.',
				'can_retry'   => true,
				'can_rollback' => true,
			);
		}

		return array(
			'mode'               => (string) ( $status['mode'] ?? 'wordpress' ),
			'setup_completed'    => (bool) ( $status['setup_completed'] ?? false ),
			'validation_passed'  => (bool) ( $status['validation_passed'] ?? false ),
			'validation_states'  => $validation_states,
			'missing_requirements' => $missing,
			'recovery_suggestions' => $recovery_suggestions,
			'retry_controls'     => array(
				'validate_endpoint' => '/wp-json/marveo/v1/deployment-status',
				'max_retries'       => 3,
				'next_retry_hint'   => 'Resolve missing requirements and call this endpoint again.',
			),
			'last_validated_at'  => $status['last_validated_at'] ?? current_time( 'mysql' ),
		);
	}

	/**
	 * GET /site-profile
	 */
	public static function get_site_profile() {
		$profile = marveo_get_deployment_profile();
		return rest_ensure_response( array(
			'site_id'            => marveo_get_site_id(),
			'site_url'           => get_option( 'siteurl' ),
			'site_name'          => get_bloginfo( 'name' ),
			'wordpress_version'  => get_bloginfo( 'version' ),
			'woocommerce_enabled' => (bool) marveo_get_woocommerce_version(),
			'mode'               => $profile['mode'] ?? 'wordpress',
			'business_profile'   => array(
				'business_name'   => (string) ( $profile['business_name'] ?? get_bloginfo( 'name' ) ),
				'industry'        => (string) ( $profile['industry'] ?? '' ),
				'business_model'  => (string) ( $profile['business_model'] ?? '' ),
				'country_currency' => (string) ( $profile['country_currency'] ?? '' ),
			),
		) );
	}

	/**
	 * GET /settings
	 */
	public static function get_public_settings() {
		$business = get_option( 'marveo_settings_business_profile', array() );
		$brand = get_option( 'marveo_settings_brand_settings', array() );
		$content = get_option( 'marveo_settings_content_settings', array() );
		$integrations = get_option( 'marveo_settings_integration_settings', array() );
		$profile = marveo_get_deployment_profile();

		return rest_ensure_response( array(
			'business_profile' => array_merge(
				array(
					'business_name'  => (string) ( $profile['business_name'] ?? get_bloginfo( 'name' ) ),
					'contact_email'  => (string) ( $profile['contact_email'] ?? get_option( 'admin_email', '' ) ),
					'contact_phone'  => (string) ( $profile['whatsapp_phone'] ?? '' ),
				),
				is_array( $business ) ? $business : array()
			),
			'brand_settings'   => is_array( $brand ) ? $brand : array(),
			'content_settings' => is_array( $content ) ? $content : array(),
			'integration_settings' => array(
				'google_analytics' => is_array( $integrations ) ? ( $integrations['google_analytics'] ?? '' ) : '',
				'meta_pixel'       => is_array( $integrations ) ? ( $integrations['meta_pixel'] ?? '' ) : '',
			),
		) );
	}

	/**
	 * GET /brand
	 */
	public static function get_brand() {
		$profile = marveo_get_deployment_profile();
		$brand = get_option( 'marveo_settings_brand_settings', array() );
		return rest_ensure_response( array(
			'logo'            => $brand['logo'] ?? ( $profile['logo'] ?? '' ),
			'favicon'         => $brand['favicon'] ?? ( $profile['favicon'] ?? '' ),
			'primary_color'   => $brand['primary_color'] ?? ( $profile['primary_color'] ?? '#14B8A6' ),
			'secondary_color' => $brand['secondary_color'] ?? ( $profile['secondary_color'] ?? '#A3E635' ),
			'typography'      => $brand['typography'] ?? ( $profile['typography'] ?? 'Inter' ),
		) );
	}

	/**
	 * GET /pages
	 */
	public static function get_pages() {
		$items = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => -1,
			'orderby'        => 'menu_order',
		) );

		$pages = array_map(
			static function( $page ) {
				return array(
					'id'                     => (int) $page->ID,
					'title'                  => (string) $page->post_title,
					'slug'                   => (string) $page->post_name,
					'page_type'              => 'page',
					'source'                 => 'wordpress',
					'seo'                    => array(),
					'components'             => array(),
					'navigation_visibility'  => true,
					'frontend_visibility'    => 'publish' === $page->post_status,
					'template'               => get_page_template_slug( $page->ID ) ?: 'default',
					'status'                 => (string) $page->post_status,
				);
			},
			$items
		);

		return rest_ensure_response( $pages );
	}

	/**
	 * GET /navigation
	 */
	public static function get_navigation() {
		$menus = wp_get_nav_menus();
		$response = array();

		foreach ( $menus as $menu ) {
			$items = wp_get_nav_menu_items( $menu->term_id );
			$response[] = array(
				'id'    => (int) $menu->term_id,
				'name'  => (string) $menu->name,
				'slug'  => (string) $menu->slug,
				'items' => array_map(
					static function( $item ) {
						return array(
							'id'    => (int) $item->ID,
							'label' => (string) $item->title,
							'url'   => (string) $item->url,
							'parent' => (int) $item->menu_item_parent,
						);
					},
					is_array( $items ) ? $items : array()
				),
			);
		}

		return rest_ensure_response( $response );
	}

	/**
	 * GET /components
	 */
	public static function get_components() {
		$registry = array(
			array( 'key' => 'hero', 'name' => 'Hero', 'category' => 'layout', 'fields' => array( 'title', 'subtitle', 'cta' ), 'allowed_page_types' => array( 'home', 'landing', 'page' ), 'data_source' => 'settings', 'visibility' => 'public' ),
			array( 'key' => 'product_grid', 'name' => 'Product Grid', 'category' => 'commerce', 'fields' => array( 'title', 'limit', 'category' ), 'allowed_page_types' => array( 'home', 'catalog', 'page' ), 'data_source' => 'products', 'visibility' => 'public' ),
			array( 'key' => 'testimonials', 'name' => 'Testimonials', 'category' => 'content', 'fields' => array( 'title', 'items' ), 'allowed_page_types' => array( 'home', 'about', 'page' ), 'data_source' => 'settings', 'visibility' => 'public' ),
			array( 'key' => 'cta', 'name' => 'Call To Action', 'category' => 'conversion', 'fields' => array( 'title', 'description', 'button_label', 'button_url' ), 'allowed_page_types' => array( 'home', 'landing', 'page' ), 'data_source' => 'settings', 'visibility' => 'public' ),
			array( 'key' => 'banner', 'name' => 'Banner', 'category' => 'content', 'fields' => array( 'image', 'title' ), 'allowed_page_types' => array( 'home', 'page' ), 'data_source' => 'settings', 'visibility' => 'public' ),
			array( 'key' => 'services', 'name' => 'Services', 'category' => 'content', 'fields' => array( 'items' ), 'allowed_page_types' => array( 'home', 'services', 'page' ), 'data_source' => 'settings', 'visibility' => 'public' ),
			array( 'key' => 'faq', 'name' => 'FAQ', 'category' => 'support', 'fields' => array( 'items' ), 'allowed_page_types' => array( 'home', 'faq', 'page' ), 'data_source' => 'settings', 'visibility' => 'public' ),
			array( 'key' => 'newsletter', 'name' => 'Newsletter', 'category' => 'conversion', 'fields' => array( 'title', 'description' ), 'allowed_page_types' => array( 'home', 'blog', 'page' ), 'data_source' => 'settings', 'visibility' => 'public' ),
			array( 'key' => 'blog_preview', 'name' => 'Blog Preview', 'category' => 'content', 'fields' => array( 'title', 'limit' ), 'allowed_page_types' => array( 'home', 'blog', 'page' ), 'data_source' => 'blog', 'visibility' => 'public' ),
		);

		return rest_ensure_response( $registry );
	}

	/**
	 * GET /products
	 */
	public static function get_products() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return rest_ensure_response( array() );
		}

		$products = wc_get_products( array(
			'limit'  => 24,
			'status' => array( 'publish' ),
			'orderby' => 'date',
			'order' => 'DESC',
		) );

		return rest_ensure_response( array_map(
			static function( $product ) {
				return array(
					'id'    => (int) $product->get_id(),
					'name'  => (string) $product->get_name(),
					'slug'  => (string) $product->get_slug(),
					'price' => (string) $product->get_price(),
					'image' => wp_get_attachment_image_url( $product->get_image_id(), 'large' ),
				);
			},
			$products
		) );
	}

	/**
	 * GET /blog
	 */
	public static function get_blog() {
		$posts = get_posts( array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => 12,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );

		return rest_ensure_response( array_map(
			static function( $post ) {
				return array(
					'id'      => (int) $post->ID,
					'title'   => (string) $post->post_title,
					'slug'    => (string) $post->post_name,
					'excerpt' => wp_strip_all_tags( $post->post_excerpt ),
					'date'    => (string) $post->post_date,
				);
			},
			$posts
		) );
	}

	/**
	 * GET /seo
	 */
	public static function get_seo() {
		$settings = get_option( 'marveo_settings_seo_settings', array() );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		return rest_ensure_response( array(
			'site_title'       => $settings['site_title'] ?? get_bloginfo( 'name' ),
			'site_description' => $settings['site_description'] ?? get_bloginfo( 'description' ),
			'site_keywords'    => $settings['site_keywords'] ?? '',
		) );
	}

	/**
	 * GET /deployment-status
	 */
	public static function get_deployment_status_payload() {
		return rest_ensure_response( self::build_deployment_status_payload() );
	}

	/**
	 * POST /content-mapping
	 */
	public static function save_content_mapping( $request ) {
		$params = $request->get_json_params();
		$audit_id = sanitize_text_field( (string) $request->get_header( 'X-Marveo-Audit-Id' ) );

		$workspace_id = sanitize_text_field( (string) ( $params['workspace_id'] ?? '' ) );
		$command_id = sanitize_text_field( (string) ( $params['command_id'] ?? '' ) );
		$mappings = isset( $params['mappings'] ) && is_array( $params['mappings'] ) ? $params['mappings'] : array();

		if ( empty( $workspace_id ) ) {
			return new WP_Error( 'missing_workspace_id', 'workspace_id is required', array( 'status' => 400 ) );
		}

		$sanitized_mappings = array();
		foreach ( $mappings as $mapping ) {
			if ( ! is_array( $mapping ) ) {
				continue;
			}

			$sanitized_mappings[] = array(
				'source_id' => sanitize_text_field( (string) ( $mapping['source_id'] ?? '' ) ),
				'source_type' => sanitize_key( (string) ( $mapping['source_type'] ?? '' ) ),
				'target_key' => sanitize_key( (string) ( $mapping['target_key'] ?? '' ) ),
				'overwrite' => ! empty( $mapping['overwrite'] ),
			);
		}

		$current = get_option( 'marveo_content_mapping', array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}

		$current[ $workspace_id ] = array(
			'command_id' => $command_id,
			'audit_id' => $audit_id,
			'updated_at' => current_time( 'mysql' ),
			'mappings' => $sanitized_mappings,
		);

		update_option( 'marveo_content_mapping', $current );
		marveo_log( 'Content mapping updated for workspace=' . $workspace_id . ' audit_id=' . $audit_id );

		return rest_ensure_response( array(
			'success' => true,
			'workspace_id' => $workspace_id,
			'command_id' => $command_id,
			'audit_id' => $audit_id,
			'updated_mappings' => count( $sanitized_mappings ),
		) );
	}

	/**
	 * POST /modules/activate
	 */
	public static function activate_modules( $request ) {
		$params = $request->get_json_params();
		$audit_id = sanitize_text_field( (string) $request->get_header( 'X-Marveo-Audit-Id' ) );

		$workspace_id = sanitize_text_field( (string) ( $params['workspace_id'] ?? '' ) );
		$command_id = sanitize_text_field( (string) ( $params['command_id'] ?? '' ) );
		$modules = isset( $params['modules'] ) && is_array( $params['modules'] ) ? $params['modules'] : array();

		if ( empty( $workspace_id ) ) {
			return new WP_Error( 'missing_workspace_id', 'workspace_id is required', array( 'status' => 400 ) );
		}

		$sanitized_modules = array_values(
			array_filter(
				array_map(
					'sanitize_key',
					$modules
				)
			)
		);

		if ( empty( $sanitized_modules ) ) {
			return new WP_Error( 'missing_modules', 'modules list cannot be empty', array( 'status' => 400 ) );
		}

		$validation = Marveo_Onboarding::validate_modules( $sanitized_modules );
		if ( empty( $validation['valid'] ) ) {
			return new WP_Error(
				'invalid_modules',
				'Module validation failed',
				array(
					'status' => 400,
					'errors' => $validation['errors'] ?? array(),
				)
			);
		}

		$profile = marveo_get_deployment_profile();
		$profile['active_modules'] = $sanitized_modules;
		marveo_save_deployment_profile( $profile );

		$command_log = get_option( 'marveo_module_activation_log', array() );
		if ( ! is_array( $command_log ) ) {
			$command_log = array();
		}

		$command_log[] = array(
			'workspace_id' => $workspace_id,
			'command_id' => $command_id,
			'audit_id' => $audit_id,
			'modules' => $sanitized_modules,
			'updated_at' => current_time( 'mysql' ),
		);

		if ( count( $command_log ) > 300 ) {
			$command_log = array_slice( $command_log, -300 );
		}
		update_option( 'marveo_module_activation_log', $command_log );

		marveo_log( 'Modules activated for workspace=' . $workspace_id . ' modules=' . implode( ',', $sanitized_modules ) . ' audit_id=' . $audit_id );

		return rest_ensure_response( array(
			'success' => true,
			'workspace_id' => $workspace_id,
			'command_id' => $command_id,
			'audit_id' => $audit_id,
			'active_modules' => $sanitized_modules,
		) );
	}

	/**
	 * Get content inventory
	 */
	public static function get_content_inventory() {
		$inventory = Marveo_Content_Discovery::get_inventory();
		return rest_ensure_response( $inventory );
	}

	/**
	 * Perform content scan
	 */
	public static function perform_content_scan() {
		$inventory = Marveo_Content_Discovery::scan_site();
		Marveo_Content_Discovery::save_inventory( $inventory );
		return rest_ensure_response( array(
			'success'   => true,
			'inventory' => $inventory,
			'message'   => 'Content scan completed',
		) );
	}

	/**
	 * Get deployment configuration
	 */
	public static function get_deployment_config() {
		$config = get_option( 'marveo_deployment_config', array() );
		return rest_ensure_response( $config );
	}

	/**
	 * Save deployment configuration
	 */
	public static function save_deployment_config( $request ) {
		$params = $request->get_json_params();

		// Validate required fields
		$required = array( 'onboarding_path', 'deployment_architecture' );
		foreach ( $required as $field ) {
			if ( ! isset( $params[ $field ] ) ) {
				return new WP_Error( 'missing_field', sprintf( 'Missing required field: %s', $field ), array( 'status' => 400 ) );
			}
		}

		update_option( 'marveo_deployment_config', $params );

		// Invalidate validation cache
		delete_option( 'marveo_validation_cache' );

		return rest_ensure_response( array(
			'success'  => true,
			'config'   => $params,
			'message'  => 'Deployment configuration saved',
		) );
	}

	/**
	 * Get settings group
	 */
	public static function get_settings_group( $request ) {
		$group = $request->get_param( 'group' );
		$groups = Marveo_Settings_Schema::get_settings_groups();

		if ( ! isset( $groups[ $group ] ) ) {
			return new WP_Error( 'invalid_group', 'Invalid settings group', array( 'status' => 404 ) );
		}

		$settings = get_option( "marveo_settings_$group", array() );

		return rest_ensure_response( array(
			'group'    => $group,
			'schema'   => $groups[ $group ],
			'settings' => $settings,
		) );
	}

	/**
	 * Save settings group
	 */
	public static function save_settings_group( $request ) {
		$group    = $request->get_param( 'group' );
		$settings = $request->get_json_params();

		update_option( "marveo_settings_$group", $settings );

		return rest_ensure_response( array(
			'success'   => true,
			'group'     => $group,
			'settings'  => $settings,
			'message'   => 'Settings saved',
		) );
	}

	/**
	 * Get modules
	 */
	public static function get_modules() {
		$modules = Marveo_Onboarding::get_modules();
		return rest_ensure_response( array(
			'modules' => $modules,
			'count'   => count( $modules ),
		) );
	}

	/**
	 * Validate modules
	 */
	public static function validate_modules( $request ) {
		$params = $request->get_json_params();
		$modules = $params['modules'] ?? array();

		$result = Marveo_Onboarding::validate_modules( $modules );

		return rest_ensure_response( $result );
	}

	/**
	 * Get onboarding paths
	 */
	public static function get_onboarding_paths() {
		$paths = Marveo_Onboarding::get_onboarding_paths();
		return rest_ensure_response( array(
			'paths'  => $paths,
			'count'  => count( $paths ),
		) );
	}

	/**
	 * Get architectures for a path
	 */
	public static function get_architectures( $request ) {
		$params = $request->get_json_params();
		$path    = $params['onboarding_path'] ?? null;

		if ( ! $path ) {
			return new WP_Error( 'missing_path', 'Missing onboarding_path', array( 'status' => 400 ) );
		}

		$architectures = Marveo_Onboarding::get_architectures_for_path( $path );

		return rest_ensure_response( array(
			'path'            => $path,
			'architectures'   => $architectures,
			'count'           => count( $architectures ),
		) );
	}

	/**
	 * Check admin permission
	 */
	public static function check_admin_permission() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Runtime permission for read-only endpoints.
	 *
	 * @return bool
	 */
	public static function check_runtime_permission() {
		$status = marveo_get_connector_status();
		return in_array( $status, array( 'pending_setup', 'active' ), true );
	}

	/**
	 * Permission for command endpoints.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return bool
	 */
	public static function check_command_permission( $request ) {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		$incoming = sanitize_text_field( (string) $request->get_header( 'X-Marveo-Command-Token' ) );
		if ( empty( $incoming ) ) {
			return false;
		}

		$stored = get_option( 'marveo_command_token', '' );
		$env = getenv( 'MARVEO_COMMAND_TOKEN' );
		$expected = ! empty( $env ) ? (string) $env : (string) $stored;

		if ( empty( $expected ) ) {
			return false;
		}

		return hash_equals( $expected, $incoming );
	}

	/**
	 * Check permission for settings group
	 */
	public static function check_permission_for_group( $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		$group  = $request->get_param( 'group' );
		$groups = Marveo_Settings_Schema::get_settings_groups();

		// System settings require higher privilege or super admin
		if ( isset( $groups[ $group ]['access'] ) && $groups[ $group ]['access'] === 'system' ) {
			return is_super_admin();
		}

		return true;
	}
}

add_action( 'rest_api_init', array( 'Marveo_REST_API_Extended', 'register_routes' ) );
