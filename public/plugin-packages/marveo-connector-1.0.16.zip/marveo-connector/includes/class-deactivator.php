<?php
/**
 * Deactivator class - handles plugin deactivation
 *
 * @package Marveo_Connector
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marveo_Deactivator class
 */
class Marveo_Deactivator {
	/**
	 * Deactivate the plugin
	 *
	 * @return void
	 */
	public static function deactivate() {
		// Remove transients
		delete_transient( 'marveo_activation_notice' );

		// Log deactivation
		marveo_log( 'Plugin deactivated.' );

		// Note: We keep the options stored so if the plugin is reactivated,
		// the connector remains in its previous state (e.g., still active)
		// If you want to completely reset on deactivation, uncomment the lines below:
		//
		// delete_option( 'marveo_activation_token' );
		// delete_option( 'marveo_activation_token_expires' );
		// delete_option( 'marveo_activated_at' );
		// delete_option( 'marveo_version' );
		// delete_option( 'marveo_site_id' );
		// delete_option( 'marveo_connector_status' );
		// delete_option( 'marveo_first_admin_created' );
		// delete_option( 'marveo_deployment_url' );
	}
}
