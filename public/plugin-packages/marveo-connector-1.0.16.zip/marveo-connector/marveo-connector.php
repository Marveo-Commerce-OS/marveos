<?php
/**
 * Plugin Name: Marvéo Connector
 * Plugin URI: https://marveocommerce.com
 * Description: Connects your WordPress/WooCommerce store to the Marvéo operations platform
 * Version: 1.0.16
 * Author: Avario Digitals
 * Author URI: https://avariodigital.com
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0-or-later.html
 * Text Domain: marveo-connector
 * Domain Path: /languages
 * Update URI: https://github.com/Marveo-Commerce-OS/marveo-connector
 * Requires: 5.9
 * Requires PHP: 7.4
 *
 * @package Marveo_Connector
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants
define( 'MARVEO_CONNECTOR_VERSION', '1.0.16' );
define( 'MARVEO_CONNECTOR_FILE', __FILE__ );
define( 'MARVEO_CONNECTOR_DIR', dirname( MARVEO_CONNECTOR_FILE ) );
define( 'MARVEO_CONNECTOR_URL', plugins_url( '', MARVEO_CONNECTOR_FILE ) );

/**
 * Main plugin class
 */
class Marveo_Connector {
	/**
	 * Instance of the plugin
	 *
	 * @var Marveo_Connector
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance
	 *
	 * @return Marveo_Connector
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->load_dependencies();
		$this->setup_hooks();
	}

	/**
	 * Load required files
	 *
	 * @return void
	 */
	private function load_dependencies() {
		require_once MARVEO_CONNECTOR_DIR . '/includes/helpers.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-update-checker.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-activator.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-deactivator.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-admin-notice.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-admin-page.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-rest-api.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-rest-api-extended.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-hooks.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-onboarding.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-content-discovery.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-settings-schema.php';
		require_once MARVEO_CONNECTOR_DIR . '/includes/class-marveo-migration.php';
	}

	/**
	 * Setup plugin hooks
	 *
	 * @return void
	 */
	private function setup_hooks() {
		Marveo_Update_Checker::init();

		// Plugin activation/deactivation
		register_activation_hook( MARVEO_CONNECTOR_FILE, array( 'Marveo_Activator', 'activate' ) );
		register_deactivation_hook( MARVEO_CONNECTOR_FILE, array( 'Marveo_Deactivator', 'deactivate' ) );

		// Initialize admin components
		if ( is_admin() ) {
			add_action( 'admin_init', array( 'Marveo_Admin_Notice', 'init' ) );
			add_action( 'admin_menu', array( 'Marveo_Admin_Page', 'add_menu' ) );
		}

		// Initialize REST API
		add_action( 'rest_api_init', array( 'Marveo_REST_API', 'register_routes' ) );

		// Initialize hooks
		add_action( 'plugins_loaded', array( 'Marveo_Hooks', 'init' ) );
	}
}

// Initialize the plugin
Marveo_Connector::get_instance();
