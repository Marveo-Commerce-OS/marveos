# Marvéo Connector WordPress Plugin

Connect your WordPress/WooCommerce store to the Marvéo operations platform.

## Overview

The **Marvéo Connector** is a WordPress plugin that bridges WordPress/WooCommerce with the Marvéo operations platform. It enables secure communication, first-time setup, and data synchronization between WordPress and Marvéo.

### Key Features

- ✅ One-click plugin activation with secure token generation
- ✅ 24-hour activation window for secure setup
- ✅ WordPress admin settings page for easy management
- ✅ REST API endpoints for Marvéo communication
- ✅ JWT authentication support
- ✅ WooCommerce integration ready
- ✅ Comprehensive security with input sanitization & nonce verification
- ✅ Placeholder hooks for Phase 2+ development

## Requirements

- **WordPress:** 5.9 or higher
- **PHP:** 7.4 or higher
- **Optional:** WooCommerce for full ecommerce features
- **Optional:** JWT Authentication for the WordPress REST API plugin

## Installation

### Via WordPress Admin

1. Download the `marveo-connector` plugin
2. Go to **Plugins → Add New**
3. Click **Upload Plugin** and select the plugin ZIP file
4. Click **Install Now**
5. Activate the plugin
6. Go to **Marvéo** in the admin menu to see your activation token

### Via WP-CLI

```bash
wp plugin install marveo-connector --activate
```

### Manual Installation

1. Upload the `marveo-connector` folder to `/wp-content/plugins/`
2. Activate the plugin from the **Plugins** page
3. Access the settings at **Marvéo → Settings** in the WordPress admin

## Setup Flow

### Step 1: Plugin Activation

When you activate the Marvéo Connector plugin:

1. **Activation Token Generated**
   - A 32-character random token is created
   - Token expires in 24 hours
   - Displayed in WordPress admin notice

2. **Metadata Stored**
   - `marveo_activated_at` - activation timestamp
   - `marveo_version` - plugin version
   - `marveo_site_id` - unique site identifier
   - `marveo_connector_status` - set to `pending_setup`

3. **Admin Notice Displayed**
   - Shows your activation token
   - Displays hours remaining until token expires
   - Provides link to Marvéo setup if URL is configured

### Step 2: Copy Activation Token

From the WordPress admin:

1. Go to **Marvéo** in the left menu
2. Under "Activation Token", copy the displayed token
3. Or retrieve via WP-CLI:
   ```bash
   wp option get marveo_activation_token
   ```

### Step 3: Complete Setup in Marvéo

1. Go to your Marvéo instance
2. Select "Setup with Activation Token"
3. Paste your token
4. Create your first Marvéo admin user
5. The plugin will validate and mark setup complete

### Step 4: Verify Active Status

In WordPress admin:
- Go to **Marvéo**
- Verify "Connector Status" shows **Active** (green)
- Verify `marveo_first_admin_created` is set to `true`

### Step 5: Complete Deployment Setup

Open **Marvéo → Deployment Setup Wizard** and save a deployment profile.

The deployment is not considered complete until:
- A deployment mode is selected
- The profile is saved
- Validation passes
- Missing requirements are cleared

Supported modes:
- **Headless WordPress + Next.js**
- **WordPress Only**

## WordPress Admin Interface

### Status Overview
Shows real-time connector status and setup progress:
- **Active (Green)** - Ready to sync with Marvéo
- **Pending Setup (Yellow)** - Waiting for initial setup
- **Disconnected (Red)** - Disconnected from Marvéo

### Deployment Setup Wizard
- Deployment mode selection
- Business profile
- Brand settings
- Commerce settings
- Module selection
- Integration settings
- Deployment validation summary

### Deployment Status Object
The REST API exposes a deployment status object containing:
- `mode`
- `setup_completed`
- `validation_passed`
- `missing_requirements`
- `active_modules`
- `client_profile`
- `last_validated_at`

### Connector Information
- Connector Status (Active/Pending/Disconnected)
- Site ID (unique identifier for this installation)
- WordPress Version
- WooCommerce Status (installed version or not installed)
- JWT Auth Status (enabled or not installed)

### Activation Token
- Current token (if valid)
- Hours remaining before expiry
- **Regenerate Token** button - creates new 24-hour token

### Marvéo Configuration
- **Deployment URL** - your Marvéo instance URL
- Allows configuring your Marvéo portal link

### Danger Zone (Active connectors only)
- **Disconnect from Marvéo** - resets all Marvéo settings
- Requires confirmation before executing

## REST API Endpoints

All endpoints use the namespace `/wp-json/marveo/v1`

### GET /status

Get current connector status. **No authentication required.**

```bash
curl https://example.com/wp-json/marveo/v1/status
```

**Response:**
```json
{
  "status": "active",
  "connector_version": "1.0.0",
  "site_id": "marveo_abc123def456",
  "wordpress_version": "6.4",
  "woocommerce_version": "8.3.1",
  "jwt_enabled": true,
  "first_admin_created": true,
  "deployment_status": {
    "mode": "wordpress",
    "setup_completed": true,
    "validation_passed": true,
    "missing_requirements": [],
    "active_modules": ["products", "blog_news"],
    "client_profile": {
      "business_name": "Example Store"
    },
    "last_validated_at": "2026-05-09 10:00:00"
  }
}
```

### GET /site-info

Get detailed site information. **Requires JWT Bearer token.**

```bash
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  https://example.com/wp-json/marveo/v1/site-info
```

**Response:**
```json
{
  "site_url": "https://example.com",
  "site_name": "Example Store",
  "admin_email": "admin@example.com",
  "woocommerce_installed": true,
  "active_plugins": ["woocommerce", "jwt-auth"],
  "multisite": false
}
```

**Permission Requirements:**
- User must be authenticated via JWT
- User must have `manage_options` or `manage_woocommerce` capability

**Error Responses:**
- `401 Unauthorized` - No valid JWT token provided
- `403 Forbidden` - User lacks required permissions

### POST /init-admin

Initialize the first Marvéo admin user. **Requires activation token.**

```bash
curl -X POST https://example.com/wp-json/marveo/v1/init-admin \
  -H "Authorization: Bearer YOUR_ACTIVATION_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "marveo_admin",
    "email": "admin@marveo.local",
    "password": "SecurePassword123!"
  }'
```

**Request Parameters:**
- `username` (required, string) - WordPress username (min 3 chars)
- `email` (required, string) - Valid email address
- `password` (required, string) - User password (min 8 chars)

**Response (Success):**
```json
{
  "success": true,
  "user_id": 2,
  "message": "Marvéo admin user created successfully"
}
```

**Error Responses:**
- `400 Bad Request` - Missing fields or invalid input
- `401 Unauthorized` - Invalid or expired token
- `409 Conflict` - Admin user already created
- `500 Internal Server Error` - User creation failed

**What Happens:**
- Creates or updates WordPress user with provided credentials
- Assigns Administrator role to user
- Marks `marveo_first_admin_created` as true
- Sets `marveo_connector_status` to `active`
- **Consumes the activation token** (cannot be reused)
- Fires `marveo_first_admin_created` hook

## Authentication

### Activation Token (for /init-admin)

**Format:** `Authorization: Bearer TOKEN`

**Validation:**
- Token must match stored `marveo_activation_token`
- Token must not have expired (checked against `marveo_activation_token_expires`)
- Token can only be used once

**Example:**
```bash
curl -X POST https://example.com/wp-json/marveo/v1/init-admin \
  -H "Authorization: Bearer abc123def456ghi789..." \
  ...
```

### JWT Bearer Token (for /site-info and other authenticated endpoints)

**Format:** `Authorization: Bearer JWT_TOKEN`

**Requirements:**
- User must have valid JWT token from `/wp-json/jwt-auth/v1/token`
- User must have `manage_options` or `manage_woocommerce` capability
- Token must not be expired

**Obtaining JWT Token:**

```bash
curl -X POST https://example.com/wp-json/jwt-auth/v1/token \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "password"
  }'
```

Response:
```json
{
  "success": true,
  "data": {
    "token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "user_email": "admin@example.com",
    "user_nicename": "admin",
    "user_display_name": "Admin"
  }
}
```

## Configuration

### WP Options Stored by Plugin

```php
// Activation & Setup
get_option( 'marveo_activated_at' );              // timestamp
get_option( 'marveo_activation_token' );          // string (24h expiry)
get_option( 'marveo_activation_token_expires' );  // timestamp
get_option( 'marveo_connector_status' );          // 'pending_setup' | 'active' | 'disconnected'
get_option( 'marveo_site_id' );                   // unique ID
get_option( 'marveo_first_admin_created' );       // boolean
get_option( 'marveo_version' );                   // plugin version
get_option( 'marveo_deployment_url' );            // Marvéo instance URL
```

### Filters

```php
// Customize token expiry (default: 24 hours)
apply_filters( 'marveo_activation_token_expiry', 60 * 60 * 24 );

// Customize JWT expiry (default: 7 days)
apply_filters( 'marveo_jwt_expiry', 60 * 60 * 24 * 7 );
```

### Actions

```php
// Fired after plugin is activated
do_action( 'marveo_activated' );

// Fired after first admin is successfully created
do_action( 'marveo_first_admin_created', $user_id );

// Placeholder hooks for future phases:
do_action( 'marveo_user_synced', $user_id, $sync_data );
do_action( 'marveo_order_synced', $order_id, $order_data );
```

## Placeholder Hooks (Phase 2+)

The plugin includes safe placeholder hooks for future synchronization features. These hooks are called but do not perform any actual sync yet:

### User Hooks
- `user_register` - when a new user is created
- `profile_update` - when a user's profile is updated
- `delete_user` - when a user is deleted
- `set_user_role` - when a user's role changes

### WooCommerce Hooks
- `woocommerce_payment_complete` - when an order payment is marked complete
- `woocommerce_order_status_changed` - when an order status changes
- `woocommerce_product_updated` - when a product is updated

**Implementation Notes:**
- All hooks are logged to debug.log when `WP_DEBUG` is enabled
- Custom action hooks are fired for extensions to hook into
- Actual sync logic will be implemented in Phase 2 and 3

## Troubleshooting

### Issue: Token has expired

**Solution:** Regenerate a new token from **Marvéo → Activation Token**

### Issue: "Can't connect" error

**Checklist:**
1. Verify JWT Auth plugin is installed and active
2. Ensure your site is using HTTPS (required for production)
3. Check that your WordPress user has Administrator role
4. Verify activation token hasn't expired (24 hour window)

### Issue: "/init-admin endpoint returns 401"

**Causes & Solutions:**
- Token is invalid or expired → Regenerate token and retry
- Token already used → Request new token from WordPress admin
- Request format incorrect → Ensure `Authorization: Bearer TOKEN` header

### Issue: JWT authentication not working

**Solution:**
1. Install [JWT Authentication for the WordPress REST API](https://wordpress.org/plugins/jwt-authentication-for-wp-rest-api/)
2. Enable the plugin
3. Test token generation:
   ```bash
   wp option get jwt_auth_secret_key
   ```

### Enable Debug Logging

Add to `wp-config.php`:

```php
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );
```

Plugin will log to `/wp-content/debug.log`

## Testing Checklist

- [ ] Plugin activates without PHP errors
- [ ] Activation token is generated (check via `wp option get marveo_activation_token`)
- [ ] Token expires in 24 hours (verify `marveo_activation_token_expires`)
- [ ] Admin notice displays with token and "Setup" button
- [ ] GET `/wp-json/marveo/v1/status` returns valid JSON
- [ ] GET `/wp-json/marveo/v1/site-info` requires valid JWT token
- [ ] POST `/wp-json/marveo/v1/init-admin` creates user and sets status to active
- [ ] Token is consumed after first setup (cannot reuse)
- [ ] Connector status changes to "active" after setup
- [ ] Settings page displays correctly
- [ ] Regenerate token button creates new valid token
- [ ] Disconnect button resets status to "disconnected"
- [ ] Plugin deactivation preserves settings
- [ ] Plugin reactivation generates new token

## Security Features

1. **Input Sanitization**
   - All user inputs are sanitized using WordPress functions
   - All database inputs are escaped for output

2. **Token Security**
   - 32-character cryptographically random tokens
   - Single-use tokens consumed after first use
   - 24-hour expiration window

3. **Authentication**
   - REST endpoints require Bearer token authentication
   - User roles validated before API access

4. **NONCE Protection**
   - WordPress nonces on all admin forms
   - Prevents CSRF attacks

5. **Error Handling**
   - No sensitive information exposed in error messages
   - Proper HTTP status codes returned (401, 403, etc.)

## Development

### File Structure

```
marveo-connector/
├── marveo-connector.php          # Main plugin file
├── includes/
│   ├── helpers.php               # Utility functions
│   ├── class-update-checker.php  # GitHub-based update detection
│   ├── class-activator.php       # Activation logic
│   ├── class-deactivator.php     # Deactivation logic
│   ├── class-admin-notice.php    # Admin notice display
│   ├── class-admin-page.php      # Settings page
│   ├── class-rest-api.php        # REST endpoints
│   └── class-hooks.php           # Placeholder hooks
├── README.md                      # This file
├── LICENSE.md                     # GPL-2.0 License
└── .gitignore
```

### Adding New Endpoints

To add a new REST endpoint:

1. Add method to `Marveo_REST_API` class
2. Register route in `register_routes()` method
3. Create permission callback as needed
4. Return response as `rest_ensure_response( $data )`

Example:

```php
register_rest_route(
    'marveo/v1',
    '/my-endpoint',
    array(
        'methods'             => 'GET',
        'callback'            => array( __CLASS__, 'get_my_endpoint' ),
        'permission_callback' => array( __CLASS__, 'check_jwt_permission' ),
    )
);
```

### Release Checklist (Auto-Update Ready)

Use this checklist for every production plugin release so users see update prompts in **WordPress → Plugins**.

1. Update plugin version in:
  - `marveo-connector.php` plugin header `Version:`
  - `MARVEO_CONNECTOR_VERSION` constant in `marveo-connector.php`
2. Commit and push the release code to `main`.
3. Create a Git tag that matches the version (recommended format: `vX.Y.Z`).
4. Push the tag to GitHub.
5. Create a GitHub Release for that tag with release notes.
6. Confirm the release/tag is visible in GitHub at:
  - `https://github.com/Marveo-Commerce-OS/marveo-connector/releases`
7. In WordPress admin, run update check:
  - **Dashboard → Updates → Check Again**
8. Verify the plugin shows an available update in **Plugins**.
9. Click **Update now** to validate one-click update path.
10. Post-release smoke test:
  - Plugin remains active
  - `Marvéo Deployment URL` remains saved
  - `/wp-json/marveo/v1/status` returns expected JSON

#### Recommended Git Commands

```bash
git checkout main
git pull origin main
git add .
git commit -m "Release v1.0.1"
git push origin main
git tag v1.0.1
git push origin v1.0.1
```

#### Optional: Private Repo / Rate Limits

If GitHub API requests are rate-limited or the repository is private, provide a token through the `marveo_connector_github_token` filter.

## Roadmap

| Phase | Version | Features |
|-------|---------|----------|
| **Phase 1** | 1.0.0 | Setup, authentication, status endpoints ← **Current** |
| **Phase 2** | 1.1.0 | User synchronization, audit logging |
| **Phase 3** | 1.2.0 | Real-time order/product sync, webhooks |
| **Phase 4** | 2.0.0 | Admin UI enhancements, advanced reporting |

## License

GPL-2.0-or-later - see LICENSE.md

## Support

For issues, questions, or feature requests, please visit:
- [Marvéo Documentation](https://docs.marveo.com)
- [GitHub Issues](https://github.com/marveocommerce/marveo-connector/issues)

## Changelog

### 1.0.0 (Initial Release)
- Plugin activation with secure token generation
- WordPress admin settings page
- REST API with status and setup endpoints
- JWT authentication support
- Placeholder hooks for future phases
- Comprehensive documentation
